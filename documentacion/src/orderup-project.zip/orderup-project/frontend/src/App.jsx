
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import Navbar from './components/common/Navbar';
import Footer from './components/common/Footer';
import ProtectedRoute from './components/common/ProtectedRoute';
import Login from './pages/Login';
import Register from './pages/Register';
import ClienteDashboard from './pages/cliente/ClienteDashboard';
import EmpleadoDashboard from './pages/empleado/EmpleadoDashboard';
import RepartidorDashboard from './pages/repartidor/RepartidorDashboard';
import AdminDashboard from './pages/admin/AdminDashboard';
import PerfilPage from './pages/cliente/PerfilPage';

function App() {
  return (
    <Router>
      <AuthProvider>
        <CartProvider>
          <div className="app">
            <Navbar />
            <main style={{ minHeight: 'calc(100vh - 200px)' }}>
              <Routes>
                <Route path="/" element={<Navigate to="/login" replace />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                
                {/* Rutas de Cliente */}
                <Route
                  path="/cliente/*"
                  element={
                    <ProtectedRoute allowedRoles={['cliente']}>
                      <ClienteDashboard />
                    </ProtectedRoute>
                  }
                />

                {/* Rutas de Empleado */}
                <Route
                  path="/empleado/*"
                  element={
                    <ProtectedRoute allowedRoles={['empleado']}>
                      <EmpleadoDashboard />
                        <PerfilPage />
                     
                    </ProtectedRoute>
                  }
                />

                {/* Rutas de Repartidor */}
                <Route
                  path="/repartidor/*"
                  element={
                    <ProtectedRoute allowedRoles={['repartidor']}>
                      <RepartidorDashboard />
                    </ProtectedRoute>
                  }
                />

                {/* Rutas de Admin */}
                <Route
                  path="/admin/*"
                  element={
                    <ProtectedRoute allowedRoles={['admin']}>
                      <AdminDashboard />
                    </ProtectedRoute>
                  }
                />

                <Route path="*" element={<Navigate to="/login" replace />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </CartProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;