import { api } from './api';

export const reporteService = {
  async getVentasDiarias(fecha) {
    try {
      const pedidos = await api.get('/pedidos');
      const fechaBusqueda = fecha || new Date().toISOString().split('T')[0];
      
      const pedidosDia = pedidos.filter(p => {
        const pedidoFecha = new Date(p.fechaHora).toISOString().split('T')[0];
        return pedidoFecha === fechaBusqueda && p.estado !== 'Cancelado';
      });

      const totalVentas = pedidosDia.reduce((sum, p) => sum + p.total, 0);
      const cantidadPedidos = pedidosDia.length;

      return {
        fecha: fechaBusqueda,
        totalVentas,
        cantidadPedidos,
        pedidos: pedidosDia
      };
    } catch (error) {
      console.error('Error obteniendo ventas diarias:', error);
      return { totalVentas: 0, cantidadPedidos: 0, pedidos: [] };
    }
  },

  async getVentasMensuales(mes, año) {
    try {
      const pedidos = await api.get('/pedidos');
      const mesActual = mes || new Date().getMonth() + 1;
      const añoActual = año || new Date().getFullYear();

      const pedidosMes = pedidos.filter(p => {
        const fecha = new Date(p.fechaHora);
        return fecha.getMonth() + 1 === mesActual && 
               fecha.getFullYear() === añoActual &&
               p.estado !== 'Cancelado';
      });

      const totalVentas = pedidosMes.reduce((sum, p) => sum + p.total, 0);
      const cantidadPedidos = pedidosMes.length;

      return {
        mes: mesActual,
        año: añoActual,
        totalVentas,
        cantidadPedidos,
        pedidos: pedidosMes
      };
    } catch (error) {
      console.error('Error obteniendo ventas mensuales:', error);
      return { totalVentas: 0, cantidadPedidos: 0, pedidos: [] };
    }
  },

  async getProductosMasVendidos(limite = 10) {
    try {
      const pedidos = await api.get('/pedidos');
      const pedidosCompletados = pedidos.filter(p => p.estado === 'Entregado');

      const productosVendidos = {};
      
      pedidosCompletados.forEach(pedido => {
        pedido.detalles.forEach(detalle => {
          const id = detalle.producto.idProducto;
          if (!productosVendidos[id]) {
            productosVendidos[id] = {
              producto: detalle.producto,
              cantidadVendida: 0,
              totalGenerado: 0
            };
          }
          productosVendidos[id].cantidadVendida += detalle.cantidad;
          productosVendidos[id].totalGenerado += detalle.subtotal;
        });
      });

      const ranking = Object.values(productosVendidos)
        .sort((a, b) => b.cantidadVendida - a.cantidadVendida)
        .slice(0, limite);

      return ranking;
    } catch (error) {
      console.error('Error obteniendo productos más vendidos:', error);
      return [];
    }
  },

  async getEstadisticasGenerales() {
    try {
      const [pedidos, productos, usuarios] = await Promise.all([
        api.get('/pedidos'),
        api.get('/productos'),
        api.get('/usuarios')
      ]);

      const totalPedidos = pedidos.length;
      const pedidosCompletados = pedidos.filter(p => p.estado === 'Entregado').length;
      const pedidosEnProceso = pedidos.filter(p => 
        ['Recibido', 'En Preparación', 'Listo para Enviar', 'En Ruta'].includes(p.estado)
      ).length;
      const pedidosCancelados = pedidos.filter(p => p.estado === 'Cancelado').length;

      const totalVentas = pedidos
        .filter(p => p.estado !== 'Cancelado')
        .reduce((sum, p) => sum + p.total, 0);

      const promedioVenta = totalPedidos > 0 ? totalVentas / totalPedidos : 0;

      const totalClientes = usuarios.filter(u => u.rol === 'cliente').length;
      const totalProductos = productos.length;
      const productosDisponibles = productos.filter(p => p.disponible).length;

      return {
        pedidos: {
          total: totalPedidos,
          completados: pedidosCompletados,
          enProceso: pedidosEnProceso,
          cancelados: pedidosCancelados
        },
        ventas: {
          total: totalVentas,
          promedio: promedioVenta
        },
        clientes: totalClientes,
        productos: {
          total: totalProductos,
          disponibles: productosDisponibles
        }
      };
    } catch (error) {
      console.error('Error obteniendo estadísticas generales:', error);
      return {};
    }
  },

  async getDesempeñoRepartidores() {
    try {
      const pedidos = await api.get('/pedidos');
      const pedidosEntregados = pedidos.filter(p => p.estado === 'Entregado');

      const desempeño = {};

      pedidosEntregados.forEach(pedido => {
        if (pedido.repartidor) {
          const id = pedido.repartidor.idUsuario;
          if (!desempeño[id]) {
            desempeño[id] = {
              repartidor: pedido.repartidor,
              totalEntregas: 0,
              totalGenerado: 0
            };
          }
          desempeño[id].totalEntregas++;
          desempeño[id].totalGenerado += pedido.total;
        }
      });

      return Object.values(desempeño)
        .sort((a, b) => b.totalEntregas - a.totalEntregas);
    } catch (error) {
      console.error('Error obteniendo desempeño de repartidores:', error);
      return [];
    }
  }
};
