import { api } from './api';

export const authService = {
  async login(email, password) {
    try {
      // 🚨 CORRECCIÓN CLAVE: Asumo que api.get() devuelve un objeto de respuesta
      // que contiene los datos en una propiedad llamada 'data', 
      // o que tu implementación de 'api.js' necesita un ajuste para devolver solo el array.
      // Si api.get ya devuelve el array, ignora la desestructuración.
      
      const response = await api.get('/usuarios');
      // Intenta acceder a la propiedad 'data' de la respuesta, si existe.
      const usuarios = response.data || response; 

      if (!Array.isArray(usuarios)) {
          throw new Error('Formato de respuesta inesperado del servidor.');
      }
      
      // Buscar usuario por email
      const user = usuarios.find(u => u.email === email);
      
      if (!user) {
        throw new Error('Usuario no encontrado');
      }
      
      // Verificar contraseña (en producción esto debe ser con hash)
      if (user.contraseña !== password) {
        throw new Error('Contraseña incorrecta');
      }
      
      // No devolver la contraseña
      const { contraseña, ...userData } = user;
      return userData;
    } catch (error) {
      // Re-lanzar el error para que AuthContext.js lo capture y lo muestre.
      throw error;
    }
  },

  async register(userData) {
    try {
      // 🚨 CORRECCIÓN CLAVE: (Misma lógica de acceso a datos)
      const response = await api.get('/usuarios');
      const usuarios = response.data || response;
      
      const existingUser = usuarios.find(u => u.email === userData.email);
      
      if (existingUser) {
        throw new Error('El email ya está registrado');
      }
      
      // Crear nuevo usuario
      const newUser = {
        idUsuario: Date.now().toString(),
        nombre: userData.nombre,
        email: userData.email,
        telefono: userData.telefono || '',
        contraseña: userData.password,
        rol: 'cliente',
        fechaRegistro: new Date().toISOString(),
        direccionPrincipal: userData.direccion || '',
        preferencias: {}
      };
      
      // Asumimos que api.post devuelve un objeto de respuesta
      await api.post('/usuarios', newUser);
      
      // No devolver la contraseña
      const { contraseña, ...userDataResponse } = newUser;
      return userDataResponse;
    } catch (error) {
      throw error;
    }
  },

  async updateProfile(userId, updates) {
    try {
      // 🚨 CORRECCIÓN CLAVE: (Misma lógica de acceso a datos)
      const response = await api.patch(`/usuarios/${userId}`, updates);
      const updatedUser = response.data || response;
      
      const { contraseña, ...userData } = updatedUser;
      return userData;
    } catch (error) {
      throw error;
    }
  }
};