import { api } from './api';

export const productService = {
  async getAllProducts() {
    try {
      const productos = await api.get('/productos');
      return productos.filter(p => p.disponible);
    } catch (error) {
      console.error('Error obteniendo productos:', error);
      return [];
    }
  },

  async getProductById(id) {
    try {
      return await api.get(`/productos/${id}`);
    } catch (error) {
      console.error('Error obteniendo producto:', error);
      throw error;
    }
  },

  async getProductsByCategory(category) {
    try {
      const productos = await api.get('/productos');
      return productos.filter(p => p.categoria === category && p.disponible);
    } catch (error) {
      console.error('Error obteniendo productos por categoría:', error);
      return [];
    }
  },

  async searchProducts(query) {
    try {
      const productos = await api.get('/productos');
      const lowerQuery = query.toLowerCase();
      return productos.filter(p => 
        p.disponible && (
          p.nombre.toLowerCase().includes(lowerQuery) ||
          p.descripcion.toLowerCase().includes(lowerQuery)
        )
      );
    } catch (error) {
      console.error('Error buscando productos:', error);
      return [];
    }
  },

  async createProduct(productData) {
    try {
      const newProduct = {
        idProducto: Date.now().toString(),
        ...productData,
        disponible: true
      };
      return await api.post('/productos', newProduct);
    } catch (error) {
      console.error('Error creando producto:', error);
      throw error;
    }
  },

  async updateProduct(id, updates) {
    try {
      return await api.patch(`/productos/${id}`, updates);
    } catch (error) {
      console.error('Error actualizando producto:', error);
      throw error;
    }
  },

  async deleteProduct(id) {
    try {
      return await api.delete(`/productos/${id}`);
    } catch (error) {
      console.error('Error eliminando producto:', error);
      throw error;
    }
  },

  async getCategories() {
    try {
      const productos = await api.get('/productos');
      const categories = [...new Set(productos.map(p => p.categoria))];
      return categories;
    } catch (error) {
      console.error('Error obteniendo categorías:', error);
      return [];
    }
  }
};
