import { api } from './api';

export const inventarioService = {
  async getAllInventario() {
    try {
      return await api.get('/inventario');
    } catch (error) {
      console.error('Error obteniendo inventario:', error);
      return [];
    }
  },

  async getInventarioById(id) {
    try {
      return await api.get(`/inventario/${id}`);
    } catch (error) {
      console.error('Error obteniendo item de inventario:', error);
      throw error;
    }
  },

  async updateInventario(id, updates) {
    try {
      return await api.patch(`/inventario/${id}`, {
        ...updates,
        ultimaActualizacion: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error actualizando inventario:', error);
      throw error;
    }
  },

  async getInventarioBajo() {
    try {
      const inventario = await api.get('/inventario');
      return inventario.filter(item => item.cantidad <= item.nivelMinimo);
    } catch (error) {
      console.error('Error obteniendo inventario bajo:', error);
      return [];
    }
  },

  async agregarStock(id, cantidad) {
    try {
      const item = await this.getInventarioById(id);
      return await this.updateInventario(id, {
        cantidad: item.cantidad + cantidad
      });
    } catch (error) {
      console.error('Error agregando stock:', error);
      throw error;
    }
  },

  async descontarStock(id, cantidad) {
    try {
      const item = await this.getInventarioById(id);
      const nuevaCantidad = Math.max(0, item.cantidad - cantidad);
      return await this.updateInventario(id, {
        cantidad: nuevaCantidad
      });
    } catch (error) {
      console.error('Error descontando stock:', error);
      throw error;
    }
  },

  async createInventarioItem(itemData) {
    try {
      const newItem = {
        idInventario: Date.now().toString(),
        ...itemData,
        ultimaActualizacion: new Date().toISOString()
      };
      return await api.post('/inventario', newItem);
    } catch (error) {
      console.error('Error creando item de inventario:', error);
      throw error;
    }
  },

  getEstadoInventario(cantidad, nivelMinimo) {
    if (cantidad === 0) return { estado: 'Agotado', class: 'text-danger' };
    if (cantidad <= nivelMinimo) return { estado: 'Bajo', class: 'text-warning' };
    return { estado: 'Disponible', class: 'text-success' };
  }
};
