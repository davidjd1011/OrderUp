// services/whatsappService.js

export const whatsappService = {
  /**
   * Envía un mensaje de WhatsApp usando la API web de WhatsApp
   * Esta función abre WhatsApp Web con el mensaje pre-escrito
   */
  enviarMensaje(telefono, mensaje) {
    try {
      // Limpiar el número de teléfono (quitar espacios, guiones, paréntesis, etc)
      let telefonoLimpio = telefono.toString().replace(/\D/g, '');
      
      // Si el número no tiene código de país, agregar 57 (Colombia)
      if (!telefonoLimpio.startsWith('57') && telefonoLimpio.length === 10) {
        telefonoLimpio = '57' + telefonoLimpio;
      }
      
      console.log('📱 Enviando WhatsApp a:', telefonoLimpio);
      
      // Codificar el mensaje para URL
      const mensajeCodificado = encodeURIComponent(mensaje);
      
      // Construir URL de WhatsApp
      const urlWhatsApp = `https://wa.me/${telefonoLimpio}?text=${mensajeCodificado}`;
      
      console.log('🔗 URL:', urlWhatsApp);
      
      // Abrir WhatsApp en una nueva ventana
      window.open(urlWhatsApp, '_blank');
      
      return true;
    } catch (error) {
      console.error('❌ Error enviando WhatsApp:', error);
      alert('Error al abrir WhatsApp. Verifica el número de teléfono.');
      return false;
    }
  },

  /**
   * Notifica al cliente cuando su pedido cambia de estado
   */
  notificarCambioPedido(pedido, nuevoEstado) {
    const mensajes = {
      'Recibido': `¡Hola ${pedido.cliente.nombre}! 👋

Tu pedido *${pedido.idPedido}* ha sido recibido exitosamente.

📦 Total: ${pedido.total.toLocaleString()}
⏰ Estamos preparando tu pedido.

Gracias por tu compra en OrderUp! 🛍️`,

      'En Preparación': `¡Hola ${pedido.cliente.nombre}! 👨‍🍳

Tu pedido *${pedido.idPedido}* está siendo preparado.

📦 Productos: ${pedido.detalles.length} items
💰 Total: ${pedido.total.toLocaleString()}

¡Pronto estará listo para envío! ⏳`,

      'Listo para Enviar': `¡Hola ${pedido.cliente.nombre}! ✅

¡Tu pedido *${pedido.idPedido}* está listo para enviar!

📦 Total: ${pedido.total.toLocaleString()}
🚚 Pronto un repartidor lo llevará a tu dirección.

Gracias por tu paciencia! 😊`,

      'En Ruta': `¡Hola ${pedido.cliente.nombre}! 🚚

Tu pedido *${pedido.idPedido}* está en camino!

📍 Dirección: ${pedido.direccionEntrega}
👤 Repartidor: ${pedido.repartidor?.nombre || 'Asignado'}
💰 Total a pagar: ${pedido.total.toLocaleString()}

¡Llegará pronto! 🎉`,

      'Entregado': `¡Hola ${pedido.cliente.nombre}! ✅

Tu pedido *${pedido.idPedido}* ha sido entregado exitosamente.

💰 Total: ${pedido.total.toLocaleString()}
📅 Entregado: ${new Date().toLocaleString('es-CO')}

¡Gracias por tu compra! Esperamos verte pronto 😊

OrderUp 🛍️`
    };

    const mensaje = mensajes[nuevoEstado];
    
    if (!mensaje) {
      console.error('❌ Estado no válido:', nuevoEstado);
      alert('Estado de pedido no válido');
      return false;
    }
    
    if (!pedido.cliente.telefono) {
      console.error('❌ Cliente sin teléfono');
      alert('El cliente no tiene número de teléfono registrado');
      return false;
    }

    return this.enviarMensaje(pedido.cliente.telefono, mensaje);
  },

  /**
   * Notifica al cliente sobre un nuevo pedido
   */
  notificarNuevoPedido(pedido) {
    const productos = pedido.detalles
      .map(d => `• ${d.cantidad}x ${d.producto.nombre}`)
      .join('\n');

    const mensaje = `¡Hola ${pedido.cliente.nombre}! 👋

¡Gracias por tu pedido en OrderUp! 🛍️

*Pedido: ${pedido.idPedido}*

📦 *Productos:*
${productos}

💰 *Total: ${pedido.total.toLocaleString()}*
📍 *Dirección:* ${pedido.direccionEntrega}

Te mantendremos informado del estado de tu pedido.

¡Gracias por tu compra! 😊`;

    return this.enviarMensaje(pedido.cliente.telefono, mensaje);
  },

  /**
   * Notifica al repartidor cuando se le asigna un pedido
   */
  notificarRepartidor(pedido) {
    if (!pedido.repartidor?.telefono) {
      console.error('❌ Repartidor sin teléfono');
      alert('El repartidor no tiene número de teléfono registrado');
      return false;
    }

    const productos = pedido.detalles
      .map(d => `• ${d.cantidad}x ${d.producto.nombre}`)
      .join('\n');

    const mensaje = `🚚 *Nuevo Pedido Asignado*

*Pedido: ${pedido.idPedido}*

👤 *Cliente:* ${pedido.cliente.nombre}
📞 *Teléfono:* ${pedido.cliente.telefono}
📍 *Dirección:* ${pedido.direccionEntrega}

📦 *Productos:*
${productos}

💰 *Total a cobrar: ${pedido.total.toLocaleString()}*

¡Buena suerte con la entrega! 🎯`;

    return this.enviarMensaje(pedido.repartidor.telefono, mensaje);
  },

  /**
   * Notifica cancelación de pedido
   */
  notificarCancelacion(pedido, motivo) {
    const mensaje = `Hola ${pedido.cliente.nombre},

Lamentamos informarte que tu pedido *${pedido.idPedido}* ha sido cancelado.

${motivo ? `Motivo: ${motivo}` : ''}

Si tienes alguna duda, por favor contáctanos.

Disculpa las molestias 🙏

OrderUp`;

    return this.enviarMensaje(pedido.cliente.telefono, mensaje);
  }
};

export default whatsappService;