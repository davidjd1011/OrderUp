import { api } from './api';

export const pedidoService = {
  async createPedido(pedidoData) {
    try {
      const pedidoId = `PED-${Date.now()}`;
      const newPedido = {
        id: pedidoId,
        idPedido: pedidoId,
        fechaHora: new Date().toISOString(),
        estado: 'Recibido',
        ...pedidoData
      };
      return await api.post('/pedidos', newPedido);
    } catch (error) {
      console.error('Error creando pedido:', error);
      throw error;
    }
  },

  async getPedidosByCliente(clienteId) {
    try {
      const pedidos = await api.get('/pedidos');
      return pedidos
        .filter(p => p.cliente.idUsuario === clienteId)
        .sort((a, b) => new Date(b.fechaHora) - new Date(a.fechaHora));
    } catch (error) {
      console.error('Error obteniendo pedidos del cliente:', error);
      return [];
    }
  },

  async getPedidoById(id) {
    try {
      // Buscar por idPedido si se pasa un ID personalizado
      if (id.startsWith('PED-')) {
        const pedidos = await api.get('/pedidos');
        return pedidos.find(p => p.idPedido === id);
      }
      return await api.get(`/pedidos/${id}`);
    } catch (error) {
      console.error('Error obteniendo pedido:', error);
      throw error;
    }
  },

  async getAllPedidos() {
    try {
      const pedidos = await api.get('/pedidos');
      return pedidos.sort((a, b) => new Date(b.fechaHora) - new Date(a.fechaHora));
    } catch (error) {
      console.error('Error obteniendo todos los pedidos:', error);
      return [];
    }
  },

  async getPedidosByEstado(estado) {
    try {
      const pedidos = await api.get('/pedidos');
      return pedidos
        .filter(p => p.estado === estado)
        .sort((a, b) => new Date(b.fechaHora) - new Date(a.fechaHora));
    } catch (error) {
      console.error('Error obteniendo pedidos por estado:', error);
      return [];
    }
  },

  async updatePedidoEstado(pedidoId, nuevoEstado) {
    try {
      // Buscar el pedido por idPedido
      const pedidos = await api.get('/pedidos');
      const pedido = pedidos.find(p => p.idPedido === pedidoId);
      
      if (!pedido) {
        throw new Error('Pedido no encontrado');
      }
      
      // Actualizar el estado
      const pedidoActualizado = {
        ...pedido,
        estado: nuevoEstado,
        ultimaActualizacion: new Date().toISOString()
      };
      
      // Usar PUT con el id real de json-server
      return await api.put(`/pedidos/${pedido.id}`, pedidoActualizado);
    } catch (error) {
      console.error('Error actualizando estado del pedido:', error);
      throw error;
    }
  },

  async asignarRepartidor(pedidoId, repartidorId) {
    try {
      console.log('=== Asignando repartidor ===');
      console.log('pedidoId:', pedidoId);
      console.log('repartidorId:', repartidorId, 'tipo:', typeof repartidorId);
      
      // Buscar el pedido
      const pedidos = await api.get('/pedidos');
      const pedido = pedidos.find(p => p.idPedido === pedidoId);
      
      if (!pedido) {
        throw new Error('Pedido no encontrado');
      }
      
      console.log('Pedido encontrado:', pedido.idPedido);
      
      // Buscar el repartidor - comparar como strings
      const usuarios = await api.get('/usuarios');
      const repartidor = usuarios.find(u => {
        const userId = String(u.id || u.idUsuario);
        const targetId = String(repartidorId);
        return userId === targetId;
      });
      
      console.log('Repartidor encontrado:', repartidor ? repartidor.nombre : 'NO ENCONTRADO');
      
      if (!repartidor) {
        console.error('Usuarios disponibles:');
        usuarios.forEach(u => console.log(`  ${u.nombre}: id="${u.id}"`));
        throw new Error(`Repartidor con ID ${repartidorId} no encontrado`);
      }
      
      // Actualizar pedido
      const pedidoActualizado = {
        ...pedido,
        repartidor: {
          idUsuario: repartidor.id || repartidor.idUsuario,
          nombre: repartidor.nombre,
          telefono: repartidor.telefono
        },
        estado: 'En Ruta',
        ultimaActualizacion: new Date().toISOString()
      };
      
      console.log('Actualizando pedido...');
      const resultado = await api.put(`/pedidos/${pedido.id}`, pedidoActualizado);
      console.log('=== Repartidor asignado exitosamente ===');
      return resultado;
    } catch (error) {
      console.error('=== ERROR asignando repartidor ===', error);
      throw error;
    }
  },

  async getPedidosByRepartidor(repartidorId) {
    try {
      const pedidos = await api.get('/pedidos');
      return pedidos
        .filter(p => p.repartidor && p.repartidor.idUsuario === repartidorId)
        .sort((a, b) => new Date(b.fechaHora) - new Date(a.fechaHora));
    } catch (error) {
      console.error('Error obteniendo pedidos del repartidor:', error);
      return [];
    }
  },

  async cancelarPedido(pedidoId, motivo) {
    try {
      // Buscar el pedido por idPedido
      const pedidos = await api.get('/pedidos');
      const pedido = pedidos.find(p => p.idPedido === pedidoId);
      
      if (!pedido) {
        throw new Error('Pedido no encontrado');
      }

      // MODIFICACIÓN: Validar que el pedido se pueda cancelar
      const estadosNoCancelables = ['En Ruta', 'Entregado', 'Cancelado'];
      if (estadosNoCancelables.includes(pedido.estado)) {
          throw new Error(`No se puede cancelar el pedido porque está en estado: ${pedido.estado}`);
      }
      
      // Actualizar el estado
      const pedidoActualizado = {
        ...pedido,
        estado: 'Cancelado',
        motivoCancelacion: motivo,
        ultimaActualizacion: new Date().toISOString()
      };
      
      // Usar PUT con el id real de json-server
      return await api.put(`/pedidos/${pedido.id}`, pedidoActualizado);
    } catch (error) {
      console.error('Error cancelando pedido:', error);
      throw error;
    }
  },

  getEstadoBadgeClass(estado) {
    const estadoClasses = {
      'Recibido': 'badge-info',
      'En Preparación': 'badge-warning',
      'Listo para Enviar': 'badge-primary',
      'En Ruta': 'badge-info',
      'Entregado': 'badge-success',
      'Cancelado': 'badge-danger'
    };
    return estadoClasses[estado] || 'badge-primary';
  }
};