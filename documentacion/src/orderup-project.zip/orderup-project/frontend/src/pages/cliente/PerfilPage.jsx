import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
// Agregamos 'Check' y 'X' para la notificación
import { User, Mail, Phone, MapPin, Save, Check, X } from 'lucide-react';

const PerfilPage = () => {
  const { user, updateUser } = useAuth();
  const [editing, setEditing] = useState(false);
  
  // Nuevo estado para controlar la alerta animada
  const [showSuccess, setShowSuccess] = useState(false);

  const [formData, setFormData] = useState({
    nombre: user?.nombre || '',
    telefono: user?.telefono || '',
    direccionPrincipal: user?.direccionPrincipal || ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    updateUser(formData);
    setEditing(false);
    
    // En lugar de alert(), activamos nuestra notificación personalizada
    setShowSuccess(true);
    
    // La ocultamos automáticamente después de 3 segundos
    setTimeout(() => {
      setShowSuccess(false);
    }, 3000);
  };

  return (
    <div className="page-container container" style={{ position: 'relative' }}>
      <h1>Mi Perfil</h1>

      {/* --- INICIO: ALERTA PERSONALIZADA ANIMADA --- */}
      <div
        style={{
          position: 'fixed',
          bottom: '24px',
          right: '24px',
          backgroundColor: '#10B981', // Color verde esmeralda
          color: 'white',
          padding: '16px 24px',
          borderRadius: '12px',
          boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          zIndex: 1000,
          // Animación:
          transition: 'all 0.5s cubic-bezier(0.68, -0.55, 0.27, 1.55)',
          opacity: showSuccess ? 1 : 0,
          transform: showSuccess ? 'translateY(0) scale(1)' : 'translateY(100px) scale(0.9)',
          pointerEvents: showSuccess ? 'auto' : 'none', // Evita clicks cuando está oculto
        }}
      >
        <div style={{ background: 'rgba(255,255,255,0.2)', padding: '4px', borderRadius: '50%' }}>
          <Check size={20} color="white" strokeWidth={3} />
        </div>
        <div>
          <h4 style={{ margin: 0, fontSize: '14px', fontWeight: 'bold' }}>¡Éxito!</h4>
          <p style={{ margin: 0, fontSize: '13px', opacity: 0.9 }}>Perfil actualizado correctamente.</p>
        </div>
        <button 
          onClick={() => setShowSuccess(false)}
          style={{ background: 'transparent', border: 'none', color: 'white', marginLeft: '8px', cursor: 'pointer' }}
        >
          <X size={16} />
        </button>
      </div>
      {/* --- FIN: ALERTA PERSONALIZADA --- */}

      <div className="profile-card card">
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">
              <User size={16} />
              <span>Nombre Completo</span>
            </label>
            <input
              type="text"
              name="nombre"
              className="form-input"
              value={formData.nombre}
              onChange={handleChange}
              disabled={!editing}
            />
          </div>

          <div className="form-group">
            <label className="form-label">
              <Mail size={16} />
              <span>Correo Electrónico</span>
            </label>
            <input
              type="email"
              className="form-input"
              value={user?.email || ''}
              disabled
            />
          </div>

          <div className="form-group">
            <label className="form-label">
              <Phone size={16} />
              <span>Teléfono</span>
            </label>
            <input
              type="tel"
              name="telefono"
              className="form-input"
              value={formData.telefono}
              onChange={handleChange}
              disabled={!editing}
            />
          </div>

          <div className="form-group">
            <label className="form-label">
              <MapPin size={16} />
              <span>Dirección Principal</span>
            </label>
            <input
              type="text"
              name="direccionPrincipal"
              className="form-input"
              value={formData.direccionPrincipal}
              onChange={handleChange}
              disabled={!editing}
            />
          </div>

          {editing ? (
            <div style={{ display: 'flex', gap: '12px' }}>
              <button type="submit" className="btn btn-success">
                <Save size={20} />
                Guardar Cambios
              </button>
              <button type="button" className="btn btn-secondary" onClick={() => setEditing(false)}>
                Cancelar
              </button>
            </div>
          ) : (
            <button type="button" className="btn btn-primary" onClick={() => setEditing(true)}>
              Editar Perfil
            </button>
          )}
        </form>
      </div>
    </div>
  );
};

export default PerfilPage;