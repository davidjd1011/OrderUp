import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import { Home, ShoppingCart, Package, User } from 'lucide-react';
import CatalogoPage from './CatalogoPage';
import CarritoPage from './CarritoPage';
import PedidosPage from './PedidosPage';
import PerfilPage from './PerfilPage';
import './Dashboard.css';

const ClienteDashboard = () => {
  return (
    <div className="dashboard">
      <Routes>
        <Route index element={<CatalogoPage />} />
        <Route path="carrito" element={<CarritoPage />} />
        <Route path="pedidos" element={<PedidosPage />} />
        <Route path="perfil" element={<PerfilPage />} />
      </Routes>
    </div>
  );
};

export default ClienteDashboard;
