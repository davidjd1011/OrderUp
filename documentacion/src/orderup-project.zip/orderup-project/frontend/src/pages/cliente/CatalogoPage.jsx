import React, { useState, useEffect } from 'react';
import { productService } from '../../services/productService';
import ProductCard from '../../components/common/ProductCard';
import { Search, Filter } from 'lucide-react';

const CatalogoPage = () => {
  const [productos, setProductos] = useState([]);
  const [filteredProductos, setFilteredProductos] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todas');
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const prods = await productService.getAllProducts();
    const cats = await productService.getCategories();
    setProductos(prods);
    setFilteredProductos(prods);
    setCategories(['Todas', ...cats]);
    setLoading(false);
  };

  useEffect(() => {
    filterProducts();
  }, [searchTerm, selectedCategory, productos]);

  const filterProducts = () => {
    let filtered = [...productos];
    if (selectedCategory !== 'Todas') {
      filtered = filtered.filter(p => p.categoria === selectedCategory);
    }
    if (searchTerm) {
      filtered = filtered.filter(p => 
        p.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.descripcion.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    setFilteredProductos(filtered);
  };

  if (loading) {
    return <div className="loading"><div className="spinner"></div></div>;
  }

  return (
    <div className="page-container container">
      <div className="page-header">
        <h1>Catálogo de Productos</h1>
        <p>Explora nuestro delicioso menú</p>
      </div>

      <div className="filters-section">
        <div className="search-box">
          <Search size={20} />
          <input
            type="text"
            placeholder="Buscar productos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>

        <div className="category-filters">
          {categories.map(cat => (
            <button
              key={cat}
              className={`filter-btn ${selectedCategory === cat ? 'active' : ''}`}
              onClick={() => setSelectedCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="products-grid">
        {filteredProductos.map(producto => (
          <ProductCard key={producto.idProducto} producto={producto} />
        ))}
      </div>

      {filteredProductos.length === 0 && (
        <div className="empty-state">
          <p>No se encontraron productos</p>
        </div>
      )}
    </div>
  );
};

export default CatalogoPage;
