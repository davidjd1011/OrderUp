// ... Importaciones existentes ...
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { pedidoService } from '../../services/pedidoService';
import { Package, Clock, MapPin, XCircle, CheckCircle } from 'lucide-react'; // Importamos CheckCircle para el Toast

// --- 1. Componente Toast Simulado (Nuevo) ---
const SuccessToast = ({ message, isVisible, onClose }) => {
    // Estilos para simular un Toast que aparece desde abajo
    const style = {
        position: 'fixed',
        bottom: isVisible ? '20px' : '-100px', // Animación de slide-up/down
        left: '50%',
        transform: 'translateX(-50%)',
        backgroundColor: '#28a745', // Verde de éxito
        color: 'white',
        padding: '15px 25px',
        borderRadius: '8px',
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
        zIndex: 2000,
        transition: 'bottom 0.5s ease-in-out', // Transición para la animación
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
    };

    useEffect(() => {
        if (isVisible) {
            // Cierra automáticamente después de 4 segundos
            const timer = setTimeout(() => {
                onClose();
            }, 4000); 
            return () => clearTimeout(timer);
        }
    }, [isVisible, onClose]);

    if (!isVisible) return null;

    return (
        <div style={style}>
            <CheckCircle size={20} />
            {message}
        </div>
    );
};

// --- Componente Modal Simulado (Del código anterior) ---
const CancelacionModal = ({ isOpen, onClose, onConfirm }) => {
  const [motivo, setMotivo] = useState('');
  
  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (motivo.trim() === '') {
      // Usar un Toast o mensaje de error en el modal en lugar de alert()
      alert('El motivo de cancelación es obligatorio.');
      return;
    }
    onConfirm(motivo);
    setMotivo('');
  };

  return (
    // ... Implementación del Modal (sin cambios) ...
    <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000 }}>
      <div className="card" style={{ padding: '20px', backgroundColor: 'white', borderRadius: '8px', maxWidth: '400px', width: '90%' }}>
        <h3>Cancelar Pedido</h3>
        <p>¿Estás seguro que deseas cancelar este pedido? Por favor, indica el motivo.</p>
        <form onSubmit={handleSubmit}>
          <textarea
            value={motivo}
            onChange={(e) => setMotivo(e.target.value)}
            placeholder="Escribe el motivo de la cancelación aquí..."
            rows="3"
            style={{ width: '100%', marginBottom: '15px', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
            required
          />
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
            <button type="button" onClick={onClose} className="btn btn-secondary">
              Mantener Pedido
            </button>
            <button type="submit" className="btn btn-danger">
              Confirmar Cancelación
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};


// --- Componente Principal Refactorizado ---

const PedidosPage = () => {
  const { user } = useAuth();
  const [pedidos, setPedidos] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const [modalState, setModalState] = useState({
    isOpen: false,
    idPedidoToCancel: null,
  });

  // 2. Nuevo estado para el Toast
  const [toast, setToast] = useState({
    isVisible: false,
    message: '',
  });

  // Función para mostrar el Toast
  const showToast = (message) => {
    setToast({ isVisible: true, message });
  };

  // Función para ocultar el Toast (se usa en el timer del Toast)
  const hideToast = () => {
    setToast({ isVisible: false, message: '' });
  };


  useEffect(() => {
    loadPedidos();
  }, []);

  const loadPedidos = async () => {
    setLoading(true);
    const data = await pedidoService.getPedidosByCliente(user.idUsuario);
    setPedidos(data);
    setLoading(false);
  };
  
  const handleCancelarClick = (idPedido) => {
    setModalState({ isOpen: true, idPedidoToCancel: idPedido });
  };
  
  const handleCloseModal = () => {
    setModalState({ isOpen: false, idPedidoToCancel: null });
  };

  // 3. Modificamos la confirmación para usar showToast
  const confirmarCancelacion = async (motivo) => {
    const idPedido = modalState.idPedidoToCancel;
    if (!idPedido) return;
    
    handleCloseModal(); 

    try {
      await pedidoService.cancelarPedido(idPedido, motivo);
      
      setPedidos(prevPedidos => 
        prevPedidos.map(p => 
          p.idPedido === idPedido 
            ? { ...p, estado: 'Cancelado', motivoCancelacion: motivo } 
            : p
        )
      );
      
      // *** CAMBIO CLAVE: Usar el Toast en lugar de alert() ***
      showToast('Pedido cancelado exitosamente'); 
      
    } catch (error) {
      console.error(error);
      // Para errores, podemos seguir usando alert() o un Toast de error personalizado
      alert('❌ Error al cancelar el pedido: ' + (error.message || 'Error desconocido'));
    }
  };

  // ... (Funciones formatPrice, formatDate, puedeCancelar sin cambios) ...

  const formatPrice = (price) => { /* ... */ };
  const formatDate = (dateString) => { /* ... */ };
  const puedeCancelar = (estado) => { /* ... */ return ['Recibido', 'En Preparación'].includes(estado); };


  if (loading) {
    return <div className="loading"><div className="spinner"></div></div>;
  }

  return (
    <div className="page-container container">
      <h1>Mis Pedidos</h1>

      {/* ... Renderizado de Pedidos (sin cambios) ... */}

      {pedidos.length === 0 ? (
        <div className="empty-state card">
          <Package size={60} color="var(--text-light)" />
          <h3>No tienes pedidos aún</h3>
          <p>Realiza tu primer pedido desde el catálogo</p>
        </div>
      ) : (
        <div className="pedidos-list">
          {pedidos.map(pedido => (
            <div key={pedido.idPedido} className="pedido-card card">
              <div className="pedido-header">
                <div>
                  <h3>{pedido.idPedido}</h3>
                  <span className={`badge ${pedidoService.getEstadoBadgeClass(pedido.estado)}`}>
                    {pedido.estado}
                  </span>
                </div>
                <div className="pedido-total">{formatPrice(pedido.total)}</div>
              </div>

              <div className="pedido-info">
                <div className="info-item">
                  <Clock size={16} />
                  <span>{formatDate(pedido.fechaHora)}</span>
                </div>
                <div className="info-item">
                  <MapPin size={16} />
                  <span>{pedido.direccionEntrega}</span>
                </div>
                {pedido.estado === 'Cancelado' && pedido.motivoCancelacion && (
                    <div className="info-item error-text">
                      <span>Motivo: {pedido.motivoCancelacion}</span>
                    </div>
                )}
              </div>

              <div className="pedido-items">
                {pedido.detalles.map(detalle => (
                  <div key={detalle.idDetalle} className="pedido-item">
                    <span>{detalle.cantidad}x {detalle.producto.nombre}</span>
                    <span>{formatPrice(detalle.subtotal)}</span>
                  </div>
                ))}
              </div>

              {puedeCancelar(pedido.estado) && (
                <div className="pedido-actions" style={{ marginTop: '1rem', borderTop: '1px solid #eee', paddingTop: '1rem' }}>
                  <button 
                    className="btn btn-danger-outline" 
                    onClick={() => handleCancelarClick(pedido.idPedido)} 
                    style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#dc3545', border: '1px solid #dc3545', padding: '0.5rem 1rem', borderRadius: '4px', background: 'transparent', cursor: 'pointer' }}
                  >
                    <XCircle size={18} />
                    Cancelar Pedido
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      
      {/* 4. Renderizar el Modal */}
      <CancelacionModal
        isOpen={modalState.isOpen}
        onClose={handleCloseModal}
        onConfirm={confirmarCancelacion}
      />
      
      {/* 5. Renderizar el Toast de éxito */}
      <SuccessToast 
        message={toast.message} 
        isVisible={toast.isVisible} 
        onClose={hideToast}
      />
    </div>
  );
};

export default PedidosPage;