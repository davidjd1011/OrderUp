import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import { pedidoService } from '../../services/pedidoService';
import { Trash2, Plus, Minus, ShoppingBag } from 'lucide-react';

// 1. Importamos SweetAlert2
import Swal from 'sweetalert2'; 

const CarritoPage = () => {
  const { cartItems, updateQuantity, removeFromCart, clearCart, getCartTotal } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [direccion, setDireccion] = useState(user?.direccionPrincipal || '');
  const [metodoPago, setMetodoPago] = useState('Efectivo');
  const [observaciones, setObservaciones] = useState('');
  const [loading, setLoading] = useState(false);

  const formatPrice = (price) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0
    }).format(price);
  };

  const handleCheckout = async () => {
    // 2. Alerta de Validación (Warning)
    if (!direccion) {
      Swal.fire({
        title: 'Falta la dirección',
        text: 'Por favor ingresa una dirección de entrega para continuar.',
        icon: 'warning',
        confirmButtonColor: '#f0ad4e',
        confirmButtonText: 'Entendido'
      });
      return;
    }

    setLoading(true);
    try {
      const pedidoData = {
        cliente: {
          idUsuario: user.idUsuario,
          nombre: user.nombre,
          telefono: user.telefono
        },
        detalles: cartItems.map((item, index) => ({
          idDetalle: (index + 1).toString(),
          producto: {
            idProducto: item.idProducto,
            nombre: item.nombre,
            precio: item.precio
          },
          cantidad: item.cantidad,
          precioUnitario: item.precio,
          subtotal: item.subtotal,
          personalizaciones: item.personalizaciones || ''
        })),
        metodoPago,
        direccionEntrega: direccion,
        total: getCartTotal(),
        observaciones
      };

      await pedidoService.createPedido(pedidoData);
      clearCart();

      // 3. Alerta de Éxito (Success con Timer)
      await Swal.fire({
        title: '¡Pedido Realizado!',
        text: 'Tu pedido ha sido procesado exitosamente.',
        icon: 'success',
        confirmButtonColor: '#28a745',
        confirmButtonText: 'Genial',
        timer: 3000, // Se cierra sola en 3 segundos si no hacen click
        timerProgressBar: true
      });
      
      navigate('/cliente/pedidos');
    } catch (error) {
      // 4. Alerta de Error (Error)
      Swal.fire({
        title: 'Error',
        text: 'Hubo un problema al realizar el pedido: ' + error.message,
        icon: 'error',
        confirmButtonColor: '#d33',
        confirmButtonText: 'Cerrar'
      });
    }
    setLoading(false);
  };

  if (cartItems.length === 0) {
    return (
      <div className="empty-cart container">
        <ShoppingBag size={80} color="var(--text-light)" />
        <h2>Tu carrito está vacío</h2>
        <p>Agrega productos desde el catálogo</p>
        <button className="btn btn-primary" onClick={() => navigate('/cliente')}>
          Ver Catálogo
        </button>
      </div>
    );
  }

  return (
    <div className="page-container container">
      <h1>Carrito de Compras</h1>

      <div className="cart-layout">
        <div className="cart-items">
          {cartItems.map(item => (
            <div key={`${item.idProducto}-${item.personalizaciones}`} className="cart-item card">
              <img src={item.imagen} alt={item.nombre} className="cart-item-image" />
              <div className="cart-item-info">
                <h3>{item.nombre}</h3>
                {item.personalizaciones && (
                  <p className="text-small text-muted">{item.personalizaciones}</p>
                )}
                <p className="cart-item-price">{formatPrice(item.precio)}</p>
              </div>
              <div className="cart-item-actions">
                <div className="quantity-controls">
                  <button onClick={() => updateQuantity(item.idProducto, item.cantidad - 1, item.personalizaciones)}>
                    <Minus size={16} />
                  </button>
                  <span>{item.cantidad}</span>
                  <button onClick={() => updateQuantity(item.idProducto, item.cantidad + 1, item.personalizaciones)}>
                    <Plus size={16} />
                  </button>
                </div>
                <div className="cart-item-subtotal">{formatPrice(item.subtotal)}</div>
                <button className="btn-icon-danger" onClick={() => removeFromCart(item.idProducto, item.personalizaciones)}>
                  <Trash2 size={20} />
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="checkout-summary card">
          <h2>Resumen del Pedido</h2>
          
          <div className="form-group">
            <label className="form-label">Dirección de Entrega</label>
            <input
              type="text"
              className="form-input"
              value={direccion}
              onChange={(e) => setDireccion(e.target.value)}
              placeholder="Ingresa tu dirección"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Método de Pago</label>
            <select className="form-select" value={metodoPago} onChange={(e) => setMetodoPago(e.target.value)}>
              <option value="Efectivo">Efectivo</option>
              <option value="Tarjeta">Tarjeta</option>
              <option value="Transferencia">Transferencia</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Observaciones (opcional)</label>
            <textarea
              className="form-textarea"
              value={observaciones}
              onChange={(e) => setObservaciones(e.target.value)}
              placeholder="Ej: Sin cebolla, extra salsa..."
              rows="3"
            />
          </div>

          <div className="summary-total">
            <span>Total:</span>
            <span className="total-amount">{formatPrice(getCartTotal())}</span>
          </div>

          <button className="btn btn-primary btn-lg" style={{width: '100%'}} onClick={handleCheckout} disabled={loading}>
            {loading ? 'Procesando...' : 'Confirmar Pedido'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CarritoPage;