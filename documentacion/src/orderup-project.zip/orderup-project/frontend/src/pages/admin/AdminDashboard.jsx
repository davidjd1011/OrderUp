import React, { useState, useEffect } from 'react';
import { reporteService } from '../../services/reporteService';
import { pedidoService } from '../../services/pedidoService';
import { whatsappService } from '../../services/whatsappService';
import { api } from '../../services/api';
import { DollarSign, Package, Users, ShoppingBag, Clock, CheckCircle, XCircle, Truck, User, MapPin, ChevronRight, MessageCircle, Edit2, Save, X } from 'lucide-react';
import Swal from 'sweetalert2';
import '../admin/Dashboard.css';

const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [topProducts, setTopProducts] = useState([]);
  const [empleados, setEmpleados] = useState([]);
  const [repartidores, setRepartidores] = useState([]);
  const [clientes, setClientes] = useState([]);
  const [pedidosActivos, setPedidosActivos] = useState([]);
  const [pedidosEntregados, setPedidosEntregados] = useState([]);
  const [editandoUsuario, setEditandoUsuario] = useState(null);
  const [datosEdicion, setDatosEdicion] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [statsData, topProds, usuarios, pedidos] = await Promise.all([
        reporteService.getEstadisticasGenerales(),
        reporteService.getProductosMasVendidos(5),
        api.get('/usuarios'),
        pedidoService.getAllPedidos()
      ]);
      
      setStats(statsData);
      setTopProducts(topProds);
      
      // Filtrar empleados y repartidores
      const empleadosList = usuarios.filter(u => u.rol === 'empleado');
      const repartidoresList = usuarios.filter(u => u.rol === 'repartidor');
      const clientesList = usuarios.filter(u => u.rol === 'cliente');
      
      setEmpleados(empleadosList);
      setRepartidores(repartidoresList);
      setClientes(clientesList);
      
      // Obtener pedidos activos (no entregados ni cancelados)
      const activos = pedidos.filter(p => 
        !['Entregado', 'Cancelado'].includes(p.estado)
      );
      setPedidosActivos(activos);
      
      // Obtener pedidos entregados (ordenados por más reciente)
      const entregados = pedidos
        .filter(p => p.estado === 'Entregado')
        .sort((a, b) => {
          const fechaA = new Date(a.ultimaActualizacion || a.fechaHora);
          const fechaB = new Date(b.ultimaActualizacion || b.fechaHora);
          return fechaB - fechaA;
        })
        .slice(0, 3); // Mostrar solo los últimos 10
      setPedidosEntregados(entregados);
      
      setLoading(false);
    } catch (error) {
      console.error('Error al cargar datos:', error);
      setLoading(false);
    }
  };

  const getEstadoColor = (estado) => {
    const colores = {
      'Recibido': '#3498db',
      'En Preparación': '#f39c12',
      'Listo para Enviar': '#9b59b6',
      'En Ruta': '#e67e22',
      'Entregado': '#27ae60',
      'Cancelado': '#e74c3c'
    };
    return colores[estado] || '#95a5a6';
  };

  const estadosSiguientes = {
    'Recibido': 'En Preparación',
    'En Preparación': 'Listo para Enviar',
    'Listo para Enviar': 'En Ruta'
    // 'En Ruta' ya no tiene siguiente estado, solo el repartidor puede marcar como entregado
  };

  const handleAvanzarEstado = async (pedido) => {
    const nuevoEstado = estadosSiguientes[pedido.estado];
    
    if (!nuevoEstado) {
      Swal.fire({
        title: 'Estado Final',
        text: 'Este pedido ya está en su estado final',
        icon: 'info',
        confirmButtonColor: '#3498db',
        confirmButtonText: 'Entendido'
      });
      return;
    }

    // Si el pedido va a "En Ruta" y no tiene repartidor, alertar
    if (nuevoEstado === 'En Ruta' && !pedido.repartidor) {
      Swal.fire({
        title: '⚠️ Repartidor Requerido',
        text: 'Debes asignar un repartidor antes de poner el pedido "En Ruta"',
        icon: 'warning',
        confirmButtonColor: '#f0ad4e',
        confirmButtonText: 'Entendido'
      });
      return;
    }

    // Confirmación antes de avanzar
    const result = await Swal.fire({
      title: '¿Avanzar Pedido?',
      html: `
        <p>Pedido: <strong>${pedido.idPedido}</strong></p>
        <p>Estado actual: <strong>${pedido.estado}</strong></p>
        <p>Nuevo estado: <strong>${nuevoEstado}</strong></p>
      `,
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3498db',
      cancelButtonColor: '#95a5a6',
      confirmButtonText: 'Sí, avanzar',
      cancelButtonText: 'Cancelar'
    });

    if (!result.isConfirmed) return;

    try {
      await pedidoService.updatePedidoEstado(pedido.idPedido, nuevoEstado);
      
      // Notificar al cliente por WhatsApp
      whatsappService.notificarCambioPedido(pedido, nuevoEstado);
      
      // Notificación de éxito
      await Swal.fire({
        title: '✅ Pedido Actualizado',
        html: `
          <p>Pedido <strong>${pedido.idPedido}</strong></p>
          <p>Nuevo estado: <strong>${nuevoEstado}</strong></p>
          <p style="color: #25D366; margin-top: 10px;">
            📱 Se notificó al cliente por WhatsApp
          </p>
        `,
        icon: 'success',
        confirmButtonColor: '#27ae60',
        confirmButtonText: 'Perfecto',
        timer: 3000,
        timerProgressBar: true
      });
      
      loadData(); // Recargar datos
    } catch (error) {
      console.error('Error actualizando pedido:', error);
      Swal.fire({
        title: '❌ Error',
        text: 'No se pudo actualizar el pedido. Intenta de nuevo.',
        icon: 'error',
        confirmButtonColor: '#e74c3c',
        confirmButtonText: 'Cerrar'
      });
    }
  };

  const handleNotificarCliente = (pedido) => {
    console.log('🔔 Notificando cliente...', pedido);
    
    if (!pedido.cliente.telefono) {
      Swal.fire({
        title: '⚠️ Sin Teléfono',
        text: 'Este cliente no tiene número de teléfono registrado',
        icon: 'warning',
        confirmButtonColor: '#f0ad4e',
        confirmButtonText: 'Entendido'
      });
      return;
    }
    
    const exitoso = whatsappService.notificarCambioPedido(pedido, pedido.estado);
    
    if (exitoso) {
      console.log('✅ WhatsApp abierto correctamente');
      // Pequeña notificación toast
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
      });
      
      Toast.fire({
        icon: 'success',
        title: '📱 WhatsApp abierto',
        text: 'Se abrió WhatsApp para notificar al cliente'
      });
    }
  };

  const handleEditarUsuario = (usuario) => {
    setEditandoUsuario(usuario.id || usuario.idUsuario);
    setDatosEdicion({
      nombre: usuario.nombre,
      telefono: usuario.telefono,
      email: usuario.email || ''
    });
  };

  const handleCancelarEdicion = () => {
    setEditandoUsuario(null);
    setDatosEdicion({});
  };

  const handleGuardarUsuario = async (usuario, rol) => {
    try {
      const usuarioActualizado = {
        ...usuario,
        nombre: datosEdicion.nombre,
        telefono: datosEdicion.telefono,
        email: datosEdicion.email
      };

      await api.put(`/usuarios/${usuario.id}`, usuarioActualizado);
      
      // Notificación de éxito con animación
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 2500,
        timerProgressBar: true,
        didOpen: (toast) => {
          toast.addEventListener('mouseenter', Swal.stopTimer)
          toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
      });
      
      Toast.fire({
        icon: 'success',
        title: '✅ Usuario Actualizado',
        text: `${datosEdicion.nombre} ha sido actualizado correctamente`
      });
      
      setEditandoUsuario(null);
      setDatosEdicion({});
      loadData(); // Recargar datos
    } catch (error) {
      console.error('Error actualizando usuario:', error);
      Swal.fire({
        title: '❌ Error',
        text: 'No se pudo actualizar el usuario. Intenta de nuevo.',
        icon: 'error',
        confirmButtonColor: '#e74c3c',
        confirmButtonText: 'Cerrar'
      });
    }
  };

  const handleCambioEdicion = (campo, valor) => {
    setDatosEdicion(prev => ({
      ...prev,
      [campo]: valor
    }));
  };

  if (loading) {
    return (
      <div className="dashboard-container">
        <div className="loading-spinner">Cargando dashboard...</div>
      </div>
    );
  }

  return (
    <div className="dashboard-container">
      <div className="dashboard-header">
        <h1>Panel de Administración</h1>
        <p>Vista general del sistema OrderUp</p>
      </div>

      {/* Tarjetas de estadísticas principales */}
      <div className="stats-grid">
        <StatCard 
          icon={<DollarSign />} 
          value={`$ ${stats.ventas.total.toLocaleString()}`}
          label="Ventas Totales"
          color="green"
        />
        <StatCard 
          icon={<Package />} 
          value={stats.pedidos.total}
          label="Total Pedidos"
          color="blue"
        />
        <StatCard 
          icon={<Users />} 
          value={stats.clientes}
          label="Clientes Registrados"
          color="orange"
        />
        <StatCard 
          icon={<ShoppingBag />} 
          value={stats.productos.disponibles}
          label="Productos Disponibles"
          color="red"
        />
      </div>

      {/* Estado de Pedidos */}
      <div className="pedidos-section">
        <h2>Estado de Pedidos</h2>
        <div className="status-grid">
          <StatusCard 
            icon={<Clock />}
            value={stats.pedidos.enProceso} 
            label="En Proceso" 
            color="orange" 
          />
          <StatusCard 
            icon={<CheckCircle />}
            value={stats.pedidos.completados} 
            label="Completados" 
            color="green" 
          />
          <StatusCard 
            icon={<XCircle />}
            value={stats.pedidos.cancelados} 
            label="Cancelados" 
            color="red" 
          />
        </div>
      </div>

      {/* Personal: Empleados y Repartidores */}
      <div className="personal-section">
        <div className="personal-grid">
          {/* Empleados */}
          <div className="personal-card">
            <div className="personal-header">
              <User size={24} />
              <h3>Empleados ({empleados.length})</h3>
            </div>
            <div className="personal-list">
              {empleados.length > 0 ? (
                empleados.map(emp => (
                  <div key={emp.id || emp.idUsuario} className="personal-item">
                    {editandoUsuario === (emp.id || emp.idUsuario) ? (
                      // Modo edición
                      <div className="personal-edit-form">
                        <input
                          type="text"
                          value={datosEdicion.nombre}
                          onChange={(e) => handleCambioEdicion('nombre', e.target.value)}
                          placeholder="Nombre"
                          className="edit-input"
                        />
                        <input
                          type="tel"
                          value={datosEdicion.telefono}
                          onChange={(e) => handleCambioEdicion('telefono', e.target.value)}
                          placeholder="Teléfono"
                          className="edit-input"
                        />
                        <div className="edit-buttons">
                          <button 
                            className="btn-save-edit"
                            onClick={() => handleGuardarUsuario(emp, 'empleado')}
                          >
                            <Save size={16} />
                          </button>
                          <button 
                            className="btn-cancel-edit"
                            onClick={handleCancelarEdicion}
                          >
                            <X size={16} />
                          </button>
                        </div>
                      </div>
                    ) : (
                      // Modo visualización
                      <>
                        <div className="personal-avatar">
                          {emp.nombre.charAt(0).toUpperCase()}
                        </div>
                        <div className="personal-info">
                          <p className="personal-name">{emp.nombre}</p>
                          <p className="personal-detail">{emp.telefono}</p>
                        </div>
                        <button 
                          className="btn-edit-icon"
                          onClick={() => handleEditarUsuario(emp)}
                          title="Editar"
                        >
                          <Edit2 size={16} />
                        </button>
                      </>
                    )}
                  </div>
                ))
              ) : (
                <p className="no-data-small">No hay empleados registrados</p>
              )}
            </div>
          </div>

          {/* Repartidores */}
          <div className="personal-card">
            <div className="personal-header">
              <Truck size={24} />
              <h3>Repartidores ({repartidores.length})</h3>
            </div>
            <div className="personal-list">
              {repartidores.length > 0 ? (
                repartidores.map(rep => (
                  <div key={rep.id || rep.idUsuario} className="personal-item">
                    {editandoUsuario === (rep.id || rep.idUsuario) ? (
                      // Modo edición
                      <div className="personal-edit-form">
                        <input
                          type="text"
                          value={datosEdicion.nombre}
                          onChange={(e) => handleCambioEdicion('nombre', e.target.value)}
                          placeholder="Nombre"
                          className="edit-input"
                        />
                        <input
                          type="tel"
                          value={datosEdicion.telefono}
                          onChange={(e) => handleCambioEdicion('telefono', e.target.value)}
                          placeholder="Teléfono"
                          className="edit-input"
                        />
                        <div className="edit-buttons">
                          <button 
                            className="btn-save-edit"
                            onClick={() => handleGuardarUsuario(rep, 'repartidor')}
                          >
                            <Save size={16} />
                          </button>
                          <button 
                            className="btn-cancel-edit"
                            onClick={handleCancelarEdicion}
                          >
                            <X size={16} />
                          </button>
                        </div>
                      </div>
                    ) : (
                      // Modo visualización
                      <>
                        <div className="personal-avatar repartidor">
                          {rep.nombre.charAt(0).toUpperCase()}
                        </div>
                        <div className="personal-info">
                          <p className="personal-name">{rep.nombre}</p>
                          <p className="personal-detail">{rep.telefono}</p>
                        </div>
                        <button 
                          className="btn-edit-icon"
                          onClick={() => handleEditarUsuario(rep)}
                          title="Editar"
                        >
                          <Edit2 size={16} />
                        </button>
                      </>
                    )}
                  </div>
                ))
              ) : (
                <p className="no-data-small">No hay repartidores registrados</p>
              )}
            </div>
          </div>

          {/* Clientes */}
          <div className="personal-card">
            <div className="personal-header">
              <Users size={24} />
              <h3>Clientes ({clientes.length})</h3>
            </div>
            <div className="personal-list">
              {clientes.length > 0 ? (
                clientes.map(cliente => (
                  <div key={cliente.id || cliente.idUsuario} className="personal-item">
                    {editandoUsuario === (cliente.id || cliente.idUsuario) ? (
                      // Modo edición
                      <div className="personal-edit-form">
                        <input
                          type="text"
                          value={datosEdicion.nombre}
                          onChange={(e) => handleCambioEdicion('nombre', e.target.value)}
                          placeholder="Nombre"
                          className="edit-input"
                        />
                        <input
                          type="tel"
                          value={datosEdicion.telefono}
                          onChange={(e) => handleCambioEdicion('telefono', e.target.value)}
                          placeholder="Teléfono"
                          className="edit-input"
                        />
                        <input
                          type="email"
                          value={datosEdicion.email}
                          onChange={(e) => handleCambioEdicion('email', e.target.value)}
                          placeholder="Email"
                          className="edit-input"
                        />
                        <div className="edit-buttons">
                          <button 
                            className="btn-save-edit"
                            onClick={() => handleGuardarUsuario(cliente, 'cliente')}
                          >
                            <Save size={16} />
                          </button>
                          <button 
                            className="btn-cancel-edit"
                            onClick={handleCancelarEdicion}
                          >
                            <X size={16} />
                          </button>
                        </div>
                      </div>
                    ) : (
                      // Modo visualización
                      <>
                        <div className="personal-avatar cliente">
                          {cliente.nombre.charAt(0).toUpperCase()}
                        </div>
                        <div className="personal-info">
                          <p className="personal-name">{cliente.nombre}</p>
                          <p className="personal-detail">{cliente.email}</p>
                          <p className="personal-detail">{cliente.telefono}</p>
                        </div>
                        <button 
                          className="btn-edit-icon"
                          onClick={() => handleEditarUsuario(cliente)}
                          title="Editar"
                        >
                          <Edit2 size={16} />
                        </button>
                      </>
                    )}
                  </div>
                ))
              ) : (
                <p className="no-data-small">No hay clientes registrados</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Seguimiento de Pedidos Activos */}
      <div className="pedidos-tracking-section">
        <h2>Seguimiento de Pedidos Activos ({pedidosActivos.length})</h2>
        {pedidosActivos.length > 0 ? (
          <div className="tracking-list">
            {pedidosActivos.map(pedido => (
              <div key={pedido.id || pedido.idPedido} className="tracking-card">
                <div className="tracking-header">
                  <div className="tracking-id">
                    <Package size={20} />
                    <strong>{pedido.idPedido}</strong>
                  </div>
                  <span 
                    className="tracking-badge"
                    style={{ backgroundColor: getEstadoColor(pedido.estado) }}
                  >
                    {pedido.estado}
                  </span>
                </div>
                
                <div className="tracking-body">
                  <div className="tracking-info">
                    <p><strong>Cliente:</strong> {pedido.cliente.nombre}</p>
                    <p><strong>Total:</strong> $ {pedido.total.toLocaleString()}</p>
                    <p><strong>Productos:</strong> {pedido.detalles.length} items</p>
                  </div>
                  
                  {pedido.repartidor && (
                    <div className="tracking-repartidor">
                      <MapPin size={16} />
                      <span>Repartidor: <strong>{pedido.repartidor.nombre}</strong></span>
                    </div>
                  )}
                  
                  {!pedido.repartidor && pedido.estado !== 'Recibido' && (
                    <div className="tracking-warning">
                      <span>⚠️ Sin repartidor asignado</span>
                    </div>
                  )}
                </div>

                <div className="tracking-footer">
                  <small>
                    {new Date(pedido.fechaHora).toLocaleString('es-CO', {
                      day: '2-digit',
                      month: '2-digit',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </small>
                  
                  <div className="tracking-actions">
                    <button 
                      className="btn-whatsapp"
                      onClick={() => handleNotificarCliente(pedido)}
                      title="Notificar por WhatsApp"
                    >
                      <MessageCircle size={16} />
                      WhatsApp
                    </button>
                    
                    {estadosSiguientes[pedido.estado] && (
                      <button 
                        className="btn-avanzar"
                        onClick={() => handleAvanzarEstado(pedido)}
                      >
                        Avanzar a: {estadosSiguientes[pedido.estado]}
                        <ChevronRight size={16} />
                      </button>
                    )}
                    
                    {pedido.estado === 'En Ruta' && (
                      <div className="info-repartidor-entrega">
                        ℹ️ Solo el repartidor puede marcar como entregado
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="no-data">No hay pedidos activos en este momento</p>
        )}
      </div>

      {/* Pedidos Entregados Recientemente */}
      <div className="pedidos-entregados-section">
        <h2>✅ Pedidos Entregados Recientemente ({pedidosEntregados.length})</h2>
        {pedidosEntregados.length > 0 ? (
          <div className="tracking-list">
            {pedidosEntregados.map(pedido => (
              <div key={pedido.id || pedido.idPedido} className="tracking-card entregado">
                <div className="tracking-header entregado-header-compact">
                  <div className="tracking-id">
                    <CheckCircle size={20} />
                    <strong>{pedido.idPedido}</strong>
                  </div>
                  <span className="tracking-badge entregado-badge">
                    Entregado
                  </span>
                </div>
                
                <div className="tracking-body">
                  <div className="tracking-info">
                    <p><strong>Cliente:</strong> {pedido.cliente.nombre}</p>
                    <p><strong>Teléfono:</strong> {pedido.cliente.telefono}</p>
                    <p><strong>Dirección:</strong> {pedido.direccionEntrega}</p>
                    <p><strong>Total:</strong> $ {pedido.total.toLocaleString()}</p>
                  </div>
                  
                  {pedido.repartidor && (
                    <div className="tracking-repartidor entregado-repartidor">
                      <MapPin size={16} />
                      <span>Entregado por: <strong>{pedido.repartidor.nombre}</strong></span>
                    </div>
                  )}
                </div>

                <div className="tracking-footer">
                  <small>
                    Entregado: {new Date(pedido.ultimaActualizacion || pedido.fechaHora).toLocaleString('es-CO', {
                      day: '2-digit',
                      month: '2-digit',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </small>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="no-data">No hay pedidos entregados aún</p>
        )}
      </div>

      {/* Top 5 Productos Más Vendidos */}
      <div className="top-products-section">
        <h2>Top 5 Productos Más Vendidos</h2>
        {topProducts.length > 0 ? (
          <div className="products-list">
            {topProducts.map((item, index) => (
              <div key={item.producto.idProducto} className="product-item">
                <div className="product-rank">#{index + 1}</div>
                <div className="product-info">
                  <h3>{item.producto.nombre}</h3>
                  <p className="product-stats">
                    <span className="cantidad">
                      {item.cantidadVendida} unidades vendidas
                    </span>
                    <span className="total">
                      $ {item.totalGenerado.toLocaleString()} generados
                    </span>
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="no-data">No hay datos de productos vendidos</p>
        )}
      </div>

      {/* Estadísticas Adicionales */}
      <div className="stats-additional">
        <div className="stat-box">
          <h3>Promedio por Venta</h3>
          <p className="stat-value">$ {stats.ventas.promedio.toLocaleString(undefined, {maximumFractionDigits: 0})}</p>
        </div>
        <div className="stat-box">
          <h3>Tasa de Éxito</h3>
          <p className="stat-value">
            {stats.pedidos.total > 0 
              ? ((stats.pedidos.completados / stats.pedidos.total) * 100).toFixed(1)
              : 0}%
          </p>
        </div>
        <div className="stat-box">
          <h3>Productos Totales</h3>
          <p className="stat-value">{stats.productos.total}</p>
        </div>
      </div>
    </div>
  );
};

// Componente StatCard
const StatCard = ({ icon, value, label, color }) => {
  return (
    <div className={`stat-card stat-card-${color}`}>
      <div className="stat-icon">{icon}</div>
      <div className="stat-content">
        <div className="stat-value">{value}</div>
        <div className="stat-label">{label}</div>
      </div>
    </div>
  );
};

// Componente StatusCard
const StatusCard = ({ icon, value, label, color }) => {
  return (
    <div className={`status-card status-${color}`}>
      <div className="status-icon">{icon}</div>
      <div className="status-value">{value}</div>
      <div className="status-label">{label}</div>
    </div>
  );
};

export default AdminDashboard;