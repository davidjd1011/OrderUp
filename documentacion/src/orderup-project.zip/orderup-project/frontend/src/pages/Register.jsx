import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../services/api';
import { User, Mail, Lock, Phone, MapPin, UserCircle, Truck } from 'lucide-react';
import './Auth.css';

const Register = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    telefono: '',
    contraseña: '',
    confirmarContraseña: '',
    rol: 'cliente', // Por defecto cliente
    direccionPrincipal: '',
    // Campos adicionales para empleado
    area: '',
    turno: '',
    // Campos adicionales para repartidor
    vehiculo: '',
    zonaAsignada: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    // Validaciones
    if (formData.contraseña !== formData.confirmarContraseña) {
      setError('Las contraseñas no coinciden');
      return;
    }

    if (formData.contraseña.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres');
      return;
    }

    setLoading(true);

    try {
      // Preparar datos según el rol
      const userData = {
        id: Date.now().toString(),
        idUsuario: Date.now().toString(),
        nombre: formData.nombre,
        email: formData.email,
        telefono: formData.telefono,
        contraseña: formData.contraseña,
        rol: formData.rol,
        fechaRegistro: new Date().toISOString()
      };

      // Agregar campos específicos según el rol
      if (formData.rol === 'cliente') {
        userData.direccionPrincipal = formData.direccionPrincipal;
        userData.preferencias = {};
      } else if (formData.rol === 'empleado') {
        userData.area = formData.area || 'General';
        userData.turno = formData.turno || 'Mañana';
      } else if (formData.rol === 'repartidor') {
        userData.vehiculo = formData.vehiculo || 'Moto';
        userData.zonaAsignada = formData.zonaAsignada || 'Centro';
        userData.estado = 'Disponible';
      }

      // Verificar si el email ya existe
      const usuarios = await api.get('/usuarios');
      const emailExiste = usuarios.some(u => u.email === formData.email);

      if (emailExiste) {
        setError('Este correo electrónico ya está registrado');
        setLoading(false);
        return;
      }

      // Crear usuario
      await api.post('/usuarios', userData);

      alert('¡Registro exitoso! Ahora puedes iniciar sesión');
      navigate('/login');
    } catch (err) {
      console.error('Error en el registro:', err);
      setError('Error al crear la cuenta. Por favor intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="auth-header">
          <div className="logo-large">
            <span className="logo-text">Order</span>
            <span className="logo-accent">Up</span>
          </div>
          <h2>Crear una cuenta</h2>
          <p>Completa tus datos para registrarte</p>
        </div>

        {error && (
          <div className="alert alert-error">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="auth-form">
          {/* Selector de Rol */}
          <div className="form-group">
            <label>
              <UserCircle size={16} />
              Tipo de Cuenta
            </label>
            <select
              name="rol"
              className="form-input"
              value={formData.rol}
              onChange={handleChange}
              required
            >
              <option value="cliente">Cliente</option>
              <option value="empleado">Empleado</option>
              <option value="repartidor">Repartidor</option>
            </select>
            <small className="form-help">
              {formData.rol === 'cliente' && 'Realiza pedidos y gestiona tus compras'}
              {formData.rol === 'empleado' && 'Gestiona pedidos y prepara órdenes'}
              {formData.rol === 'repartidor' && 'Entrega pedidos a los clientes'}
            </small>
          </div>

          {/* Campos comunes */}
          <div className="form-group">
            <label>
              <User size={16} />
              Nombre Completo
            </label>
            <input
              type="text"
              name="nombre"
              className="form-input"
              placeholder="Juan Pérez"
              value={formData.nombre}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>
              <Mail size={16} />
              Correo Electrónico
            </label>
            <input
              type="email"
              name="email"
              className="form-input"
              placeholder="tu@email.com"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>
              <Phone size={16} />
              Teléfono
            </label>
            <input
              type="tel"
              name="telefono"
              className="form-input"
              placeholder="3001234567"
              value={formData.telefono}
              onChange={handleChange}
              required
            />
          </div>

          {/* Campos específicos por rol */}
          {formData.rol === 'cliente' && (
            <div className="form-group">
              <label>
                <MapPin size={16} />
                Dirección Principal
              </label>
              <input
                type="text"
                name="direccionPrincipal"
                className="form-input"
                placeholder="Calle 5 #10-20, Cali"
                value={formData.direccionPrincipal}
                onChange={handleChange}
                required
              />
            </div>
          )}

          {formData.rol === 'empleado' && (
            <>
              <div className="form-group">
                <label>
                  <User size={16} />
                  Área de Trabajo
                </label>
                <select
                  name="area"
                  className="form-input"
                  value={formData.area}
                  onChange={handleChange}
                  required
                >
                  <option value="">Seleccionar área...</option>
                  <option value="Almacén">Almacén</option>
                  <option value="Cocina">Cocina</option>
                  <option value="Atención al Cliente">Atención al Cliente</option>
                  <option value="Administración">Administración</option>
                </select>
              </div>

              <div className="form-group">
                <label>
                  <User size={16} />
                  Turno
                </label>
                <select
                  name="turno"
                  className="form-input"
                  value={formData.turno}
                  onChange={handleChange}
                  required
                >
                  <option value="">Seleccionar turno...</option>
                  <option value="Mañana">Mañana (6am - 2pm)</option>
                  <option value="Tarde">Tarde (2pm - 10pm)</option>
                  <option value="Noche">Noche (10pm - 6am)</option>
                </select>
              </div>
            </>
          )}

          {formData.rol === 'repartidor' && (
            <>
              <div className="form-group">
                <label>
                  <Truck size={16} />
                  Tipo de Vehículo
                </label>
                <select
                  name="vehiculo"
                  className="form-input"
                  value={formData.vehiculo}
                  onChange={handleChange}
                  required
                >
                  <option value="">Seleccionar vehículo...</option>
                  <option value="Moto">Moto</option>
                  <option value="Bicicleta">Bicicleta</option>
                  <option value="Automóvil">Automóvil</option>
                  <option value="A pie">A pie</option>
                </select>
              </div>

              <div className="form-group">
                <label>
                  <MapPin size={16} />
                  Zona de Trabajo
                </label>
                <select
                  name="zonaAsignada"
                  className="form-input"
                  value={formData.zonaAsignada}
                  onChange={handleChange}
                  required
                >
                  <option value="">Seleccionar zona...</option>
                  <option value="Norte">Norte</option>
                  <option value="Sur">Sur</option>
                  <option value="Centro">Centro</option>
                  <option value="Oriente">Oriente</option>
                  <option value="Occidente">Occidente</option>
                </select>
              </div>
            </>
          )}

          <div className="form-group">
            <label>
              <Lock size={16} />
              Contraseña
            </label>
            <input
              type="password"
              name="contraseña"
              className="form-input"
              placeholder="Mínimo 6 caracteres"
              value={formData.contraseña}
              onChange={handleChange}
              required
              minLength={6}
            />
          </div>

          <div className="form-group">
            <label>
              <Lock size={16} />
              Confirmar Contraseña
            </label>
            <input
              type="password"
              name="confirmarContraseña"
              className="form-input"
              placeholder="Repite tu contraseña"
              value={formData.confirmarContraseña}
              onChange={handleChange}
              required
            />
          </div>

          <button 
            type="submit" 
            className="btn btn-primary btn-block"
            disabled={loading}
          >
            {loading ? 'Creando cuenta...' : 'Crear Cuenta'}
          </button>
        </form>

        <div className="auth-footer">
          <p>
            ¿Ya tienes una cuenta?{' '}
            <Link to="/login" className="auth-link">
              Inicia sesión aquí
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;