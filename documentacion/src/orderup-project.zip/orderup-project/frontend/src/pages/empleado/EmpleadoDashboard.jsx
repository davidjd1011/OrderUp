import React, { useState, useEffect } from 'react';
import { pedidoService } from '../../services/pedidoService';
import { inventarioService } from '../../services/inventarioService';
import { api } from '../../services/api';
import { Package, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import Swal from 'sweetalert2'; // Importar SweetAlert2
import withReactContent from 'sweetalert2-react-content'; // Importar el adaptador de React
import '../cliente/Dashboard.css';

// Inicializar MySwal
const MySwal = withReactContent(Swal);

// Configuración de la alerta tipo "Toast" (Notificación pequeña en la esquina)
const Toast = MySwal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer);
    toast.addEventListener('mouseleave', Swal.resumeTimer);
  }
});

const EmpleadoDashboard = () => {
  const [pedidos, setPedidos] = useState([]);
  const [inventario, setInventario] = useState([]);
  const [repartidores, setRepartidores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedRepartidores, setSelectedRepartidores] = useState({});
  
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [pedidosData, inventarioData, repartidoresData] = await Promise.all([
        pedidoService.getAllPedidos(),
        inventarioService.getAllInventario(),
        api.get('/usuarios')
      ]);
      
      const repartidoresFiltrados = repartidoresData.filter(u => u.rol === 'repartidor');
      
      setPedidos(pedidosData.filter(p => ['Recibido', 'En Preparación', 'Listo para Enviar'].includes(p.estado)));
      setInventario(inventarioData);
      setRepartidores(repartidoresFiltrados);
    } catch (error) {
      console.error('Error cargando datos:', error);
      // Alerta de Error Modal
      MySwal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Error al cargar los datos. Por favor recarga la página.',
        confirmButtonColor: '#d33',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleChangeEstado = async (pedidoId, nuevoEstado) => {
    try {
      await pedidoService.updatePedidoEstado(pedidoId, nuevoEstado);
      
      // Alerta de Éxito tipo Toast
      Toast.fire({
        icon: 'success',
        title: `Pedido actualizado a: ${nuevoEstado}`
      });

      await loadData();
    } catch (error) {
      console.error('Error actualizando pedido:', error);
      // Alerta de Error Modal
      MySwal.fire({
        icon: 'error',
        title: 'Error',
        text: 'No se pudo actualizar el pedido. Intenta de nuevo.',
      });
    }
  };

  const handleAsignarRepartidor = async (pedidoId, repartidorId) => {
    try {
      // Confirmación previa (Opcional, pero se ve muy bien)
      const result = await MySwal.fire({
        title: '¿Asignar repartidor?',
        text: "El pedido quedará listo para entrega",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, asignar',
        cancelButtonText: 'Cancelar'
      });

      if (result.isConfirmed) {
        await pedidoService.asignarRepartidor(pedidoId, repartidorId);
        
        // Éxito con animación
        MySwal.fire(
          '¡Asignado!',
          'El repartidor ha sido asignado correctamente.',
          'success'
        );

        setSelectedRepartidores(prev => ({ ...prev, [pedidoId]: '' }));
        await loadData();
      }
    } catch (error) {
      console.error('Error asignando repartidor:', error);
      MySwal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Error al asignar repartidor.',
      });
    }
  };

  const handleSelectChange = (pedidoId, value) => {
    setSelectedRepartidores(prev => ({ ...prev, [pedidoId]: value }));
  };

  const formatPrice = (price) => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(price);

  if (loading) return <div className="loading"><div className="spinner"></div></div>;

  const inventarioBajo = inventario.filter(i => i.cantidad <= i.nivelMinimo);

  return (
    <div className="page-container container">
      <h1>Panel de Empleado - Almacén</h1>

      {/* Alertas de Inventario */}
      {inventarioBajo.length > 0 && (
        <div className="alert alert-warning">
          <AlertTriangle size={20} />
          <span><strong>Alerta:</strong> {inventarioBajo.length} ingrediente(s) con stock bajo</span>
        </div>
      )}

      {/* Estadísticas Rápidas */}
      <div className="stats-grid">
        <div className="stat-card">
          <Clock size={32} color="var(--warning)" />
          <div className="stat-value">{pedidos.filter(p => p.estado === 'Recibido').length}</div>
          <div className="stat-label">Pedidos Recibidos</div>
        </div>
        <div className="stat-card">
          <Package size={32} color="var(--primary-blue)" />
          <div className="stat-value">{pedidos.filter(p => p.estado === 'En Preparación').length}</div>
          <div className="stat-label">En Preparación</div>
        </div>
        <div className="stat-card">
          <CheckCircle size={32} color="var(--success)" />
          <div className="stat-value">{pedidos.filter(p => p.estado === 'Listo para Enviar').length}</div>
          <div className="stat-label">Listos para Enviar</div>
        </div>
      </div>

      {/* Pedidos Pendientes */}
      <div className="section">
        <h2>Pedidos Pendientes</h2>
        {pedidos.length === 0 ? (
          <div className="empty-state card">
            <Package size={60} color="var(--text-light)" />
            <p>No hay pedidos pendientes</p>
          </div>
        ) : (
          <div className="pedidos-list">
            {pedidos.map(pedido => (
              <div key={pedido.idPedido} className="pedido-card card">
                <div className="pedido-header">
                  <div>
                    <h3>{pedido.idPedido}</h3>
                    <span className={`badge ${pedidoService.getEstadoBadgeClass(pedido.estado)}`}>{pedido.estado}</span>
                  </div>
                  <div className="pedido-total">{formatPrice(pedido.total)}</div>
                </div>

                <div className="pedido-info">
                  <div className="info-item">
                    <strong>Cliente:</strong> {pedido.cliente.nombre} - {pedido.cliente.telefono}
                  </div>
                  <div className="info-item">
                    <strong>Dirección:</strong> {pedido.direccionEntrega}
                  </div>
                </div>

                <div className="pedido-items">
                  {pedido.detalles.map(detalle => (
                    <div key={detalle.idDetalle} className="pedido-item">
                      <span>{detalle.cantidad}x {detalle.producto.nombre}</span>
                      {detalle.personalizaciones && <span className="text-small text-muted">({detalle.personalizaciones})</span>}
                    </div>
                  ))}
                </div>

                <div className="pedido-actions" style={{ marginTop: '16px', display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                  {pedido.estado === 'Recibido' && (
                    <button className="btn btn-primary btn-sm" onClick={() => handleChangeEstado(pedido.idPedido, 'En Preparación')}>
                      Comenzar Preparación
                    </button>
                  )}
                  {pedido.estado === 'En Preparación' && (
                    <button className="btn btn-success btn-sm" onClick={() => handleChangeEstado(pedido.idPedido, 'Listo para Enviar')}>
                      Marcar como Listo
                    </button>
                  )}
                  {pedido.estado === 'Listo para Enviar' && (
                    <div style={{ display: 'flex', gap: '8px', alignItems: 'center', width: '100%' }}>
                      <select 
                        className="form-select" 
                        style={{ flex: 1 }}
                        value={selectedRepartidores[pedido.idPedido] || ''}
                        onChange={(e) => handleSelectChange(pedido.idPedido, e.target.value)}
                      >
                        <option value="">Seleccionar repartidor...</option>
                        {repartidores.map(r => {
                          const repartidorId = r.id || r.idUsuario;
                          return (
                            <option key={repartidorId} value={repartidorId}>
                              {r.nombre}
                            </option>
                          );
                        })}
                      </select>
                      <button 
                        className="btn btn-primary btn-sm"
                        onClick={() => {
                          const repartidorId = selectedRepartidores[pedido.idPedido];
                          if (repartidorId) {
                            handleAsignarRepartidor(pedido.idPedido, repartidorId);
                          } else {
                            // Alerta de Advertencia (Animada)
                            Toast.fire({
                                icon: 'warning',
                                title: 'Debes seleccionar un repartidor primero'
                            });
                          }
                        }}
                      >
                        Asignar
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Inventario Bajo */}
      {inventarioBajo.length > 0 && (
        <div className="section">
          <h2>Inventario con Stock Bajo</h2>
          <div className="grid grid-2">
            {inventarioBajo.map(item => (
              <div key={item.idInventario} className="card">
                <h4>{item.ingrediente}</h4>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span className="text-danger">{item.cantidad} {item.unidadMedida}</span>
                  <span className="text-small text-muted">Mínimo: {item.nivelMinimo}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default EmpleadoDashboard;