import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { User, Mail, Phone, Briefcase, Clock, Save } from 'lucide-react';

const EmpleadoPerfil = () => {
  const { user, updateUser } = useAuth();
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({
    nombre: user?.nombre || '',
    telefono: user?.telefono || '',
    area: user?.area || '',
    turno: user?.turno || ''
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const userId = user.id || user.idUsuario;
      const updatedUser = await api.put(`/usuarios/${userId}`, {
        ...user,
        ...formData
      });

      updateUser(updatedUser);
      setEditing(false);
      alert('Perfil actualizado exitosamente');
    } catch (error) {
      console.error('Error actualizando perfil:', error);
      alert('Error al actualizar el perfil');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container container">
      <h1>Mi Perfil</h1>

      <div className="profile-card card">
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">
              <User size={16} />
              <span>Nombre Completo</span>
            </label>
            <input
              type="text"
              name="nombre"
              className="form-input"
              value={formData.nombre}
              onChange={handleChange}
              disabled={!editing}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">
              <Mail size={16} />
              <span>Correo Electrónico</span>
            </label>
            <input
              type="email"
              className="form-input"
              value={user?.email || ''}
              disabled
            />
          </div>

          <div className="form-group">
            <label className="form-label">
              <Phone size={16} />
              <span>Teléfono</span>
            </label>
            <input
              type="tel"
              name="telefono"
              className="form-input"
              value={formData.telefono}
              onChange={handleChange}
              disabled={!editing}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">
              <Briefcase size={16} />
              <span>Área de Trabajo</span>
            </label>
            {editing ? (
              <select
                name="area"
                className="form-input"
                value={formData.area}
                onChange={handleChange}
                required
              >
                <option value="">Seleccionar área...</option>
                <option value="Almacén">Almacén</option>
                <option value="Cocina">Cocina</option>
                <option value="Atención al Cliente">Atención al Cliente</option>
                <option value="Administración">Administración</option>
              </select>
            ) : (
              <input
                type="text"
                className="form-input"
                value={formData.area}
                disabled
              />
            )}
          </div>

          <div className="form-group">
            <label className="form-label">
              <Clock size={16} />
              <span>Turno</span>
            </label>
            {editing ? (
              <select
                name="turno"
                className="form-input"
                value={formData.turno}
                onChange={handleChange}
                required
              >
                <option value="">Seleccionar turno...</option>
                <option value="Mañana">Mañana (6am - 2pm)</option>
                <option value="Tarde">Tarde (2pm - 10pm)</option>
                <option value="Noche">Noche (10pm - 6am)</option>
              </select>
            ) : (
              <input
                type="text"
                className="form-input"
                value={formData.turno}
                disabled
              />
            )}
          </div>

          {editing ? (
            <div style={{ display: 'flex', gap: '12px' }}>
              <button type="submit" className="btn btn-success" disabled={loading}>
                <Save size={20} />
                {loading ? 'Guardando...' : 'Guardar Cambios'}
              </button>
              <button 
                type="button" 
                className="btn btn-secondary" 
                onClick={() => {
                  setEditing(false);
                  setFormData({
                    nombre: user?.nombre || '',
                    telefono: user?.telefono || '',
                    area: user?.area || '',
                    turno: user?.turno || ''
                  });
                }}
                disabled={loading}
              >
                Cancelar
              </button>
            </div>
          ) : (
            <button type="button" className="btn btn-primary" onClick={() => setEditing(true)}>
              Editar Perfil
            </button>
          )}
        </form>
      </div>
    </div>
  );
};

export default EmpleadoPerfil;