import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { pedidoService } from '../../services/pedidoService';
import { MapPin, Phone, CheckCircle, Package } from 'lucide-react';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import '../cliente/Dashboard.css';

// Inicializamos SweetAlert con React
const MySwal = withReactContent(Swal);

const RepartidorDashboard = () => {
  const { user } = useAuth();
  const [pedidos, setPedidos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const initDashboard = async () => {
      try {
        if (!user) {
          setLoading(false);
          setError('No se pudo cargar la información del usuario');
          return;
        }
        await loadPedidos();
      } catch (err) {
        console.error('Error en initDashboard:', err);
        setError('Error al cargar el dashboard');
        setLoading(false);
      }
    };
    
    initDashboard();
  }, [user]);

  const loadPedidos = async () => {
    try {
      setLoading(true);
      setError(null);
      
      if (!user) throw new Error('Usuario no disponible');
      
      const repartidorId = user.id || user.idUsuario;
      if (!repartidorId) throw new Error('No se pudo obtener el ID del repartidor');
      
      const data = await pedidoService.getPedidosByRepartidor(repartidorId);
      const pedidosFiltrados = data.filter(p => ['En Ruta', 'Listo para Enviar'].includes(p.estado));
      
      setPedidos(pedidosFiltrados);
    } catch (err) {
      console.error('Error cargando pedidos:', err);
      setError(err.message || 'Error al cargar los pedidos');
      
      // Alerta animada de error (opcional si ya muestras el error en el render)
      MySwal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Hubo un problema al cargar los pedidos.',
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });

    } finally {
      setLoading(false);
    }
  };

  const handleEntregado = async (pedidoId) => {
    // 1. Reemplazo de window.confirm con un modal animado
    const result = await MySwal.fire({
      title: '¿Confirmar entrega?',
      text: "¡El cliente recibirá la notificación inmediatamente!",
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#28a745', // Verde éxito
      cancelButtonColor: '#d33',    // Rojo cancelar
      confirmButtonText: 'Sí, pedido entregado',
      cancelButtonText: 'Cancelar',
      reverseButtons: true
    });

    if (result.isConfirmed) {
      try {
        // 2. Mostrar estado de carga mientras se procesa
        MySwal.fire({
          title: 'Procesando...',
          text: 'Actualizando estado del pedido',
          allowOutsideClick: false,
          didOpen: () => {
            MySwal.showLoading();
          }
        });

        await pedidoService.updatePedidoEstado(pedidoId, 'Entregado');
        
        // 3. Alerta de Éxito animada
        await MySwal.fire({
          icon: 'success',
          title: '¡Excelente!',
          text: 'El pedido ha sido marcado como entregado.',
          timer: 2000,
          showConfirmButton: false
        });

        await loadPedidos();

      } catch (err) {
        console.error('Error marcando pedido como entregado:', err);
        // 4. Alerta de Error animada
        MySwal.fire({
          icon: 'error',
          title: 'Error',
          text: 'No se pudo actualizar el pedido. Intenta nuevamente.',
        });
      }
    }
  };

  const formatPrice = (price) => new Intl.NumberFormat('es-CO', { 
    style: 'currency', 
    currency: 'COP', 
    minimumFractionDigits: 0 
  }).format(price);
  
  const formatDate = (dateString) => new Date(dateString).toLocaleString('es-CO', { 
    hour: '2-digit', 
    minute: '2-digit' 
  });

  // Renderizado de carga y errores
  if (loading && pedidos.length === 0) {
    return (
      <div className="loading">
        <div className="spinner"></div>
        <p>Cargando dashboard...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="page-container container">
        <div className="alert alert-danger">
          <h3>Error</h3>
          <p>{error}</p>
          <button className="btn btn-primary" onClick={loadPedidos}>
            Reintentar
          </button>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="page-container container">
        <div className="alert alert-warning">
          <h3>No autenticado</h3>
          <p>Por favor inicia sesión para ver el dashboard</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page-container container">
      <h1>Panel de Repartidor</h1>
      
      <div className="card" style={{ marginBottom: '20px', padding: '16px' }}>
        <p><strong>Repartidor:</strong> {user.nombre}</p>
        <p><strong>ID:</strong> {user.id || user.idUsuario}</p>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <Package size={32} color="var(--primary-blue)" />
          <div className="stat-value">{pedidos.length}</div>
          <div className="stat-label">Entregas Pendientes</div>
        </div>
      </div>

      {pedidos.length === 0 ? (
        <div className="empty-state card">
          <Package size={60} color="var(--text-light)" />
          <div style={{ marginTop: '15px' }}>
            <h3>¡Todo al día!</h3>
            <p>No tienes entregas pendientes en este momento.</p>
          </div>
        </div>
      ) : (
        <div className="pedidos-list">
          {pedidos.map(pedido => (
            <div key={pedido.idPedido} className="pedido-card card">
              <div className="pedido-header">
                <div>
                  <h3>#{pedido.idPedido}</h3>
                  <span className={`badge ${pedidoService.getEstadoBadgeClass(pedido.estado)}`}>
                    {pedido.estado}
                  </span>
                </div>
                <div className="pedido-total">{formatPrice(pedido.total)}</div>
              </div>

              <div className="pedido-info">
                <div className="info-item">
                  <MapPin size={16} />
                  <strong>{pedido.direccionEntrega}</strong>
                </div>
                <div className="info-item">
                  <Phone size={16} />
                  <span>{pedido.cliente.nombre} - {pedido.cliente.telefono}</span>
                </div>
                <div className="info-item">
                  <span className="text-small text-muted">
                    Pedido realizado: {formatDate(pedido.fechaHora)}
                  </span>
                </div>
              </div>

              <div className="pedido-items">
                <strong>Artículos:</strong>
                {pedido.detalles.map(detalle => (
                  <div key={detalle.idDetalle} className="pedido-item">
                    <span>{detalle.cantidad}x {detalle.producto.nombre}</span>
                  </div>
                ))}
              </div>

              {pedido.estado === 'En Ruta' && (
                <button 
                  className="btn btn-success" 
                  style={{ width: '100%', marginTop: '16px' }} 
                  onClick={() => handleEntregado(pedido.idPedido)}
                >
                  <CheckCircle size={20} style={{ marginRight: '8px' }} />
                  Marcar como Entregado
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default RepartidorDashboard;