import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { User, Mail, Phone, Truck, MapPin, Save } from 'lucide-react';
import '../cliente/Dashboard.css';

const RepartidorPerfil = () => {
  const { user, updateUser } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    nombre: user?.nombre || '',
    email: user?.email || '',
    telefono: user?.telefono || '',
    vehiculo: user?.vehiculo || '',
    zonaAsignada: user?.zonaAsignada || ''
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Actualizar usuario en el backend
      const userId = user.id || user.idUsuario;
      const updatedUser = await api.put(`/usuarios/${userId}`, {
        ...user,
        ...formData
      });

      // Actualizar en el contexto
      updateUser(updatedUser);
      
      alert('Perfil actualizado exitosamente');
      setIsEditing(false);
    } catch (error) {
      console.error('Error actualizando perfil:', error);
      alert('Error al actualizar el perfil');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container container">
      <h1>Mi Perfil</h1>

      <div className="card" style={{ maxWidth: '600px', margin: '0 auto' }}>
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: '24px' }}>
            <div style={{ 
              width: '80px', 
              height: '80px', 
              borderRadius: '50%', 
              background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 16px'
            }}>
              <User size={40} color="white" />
            </div>
            <h2 style={{ textAlign: 'center', marginBottom: '8px' }}>{user?.nombre}</h2>
            <p style={{ textAlign: 'center', color: '#64748b' }}>Repartidor</p>
          </div>

          <div className="form-group">
            <label>
              <User size={16} />
              Nombre Completo
            </label>
            <input
              type="text"
              name="nombre"
              className="form-input"
              value={formData.nombre}
              onChange={handleChange}
              disabled={!isEditing}
              required
            />
          </div>

          <div className="form-group">
            <label>
              <Mail size={16} />
              Correo Electrónico
            </label>
            <input
              type="email"
              name="email"
              className="form-input"
              value={formData.email}
              onChange={handleChange}
              disabled={!isEditing}
              required
            />
          </div>

          <div className="form-group">
            <label>
              <Phone size={16} />
              Teléfono
            </label>
            <input
              type="tel"
              name="telefono"
              className="form-input"
              value={formData.telefono}
              onChange={handleChange}
              disabled={!isEditing}
              required
            />
          </div>

          <div className="form-group">
            <label>
              <Truck size={16} />
              Vehículo
            </label>
            <input
              type="text"
              name="vehiculo"
              className="form-input"
              value={formData.vehiculo}
              onChange={handleChange}
              disabled={!isEditing}
              placeholder="Ej: Moto, Bicicleta, Automóvil"
            />
          </div>

          <div className="form-group">
            <label>
              <MapPin size={16} />
              Zona Asignada
            </label>
            <input
              type="text"
              name="zonaAsignada"
              className="form-input"
              value={formData.zonaAsignada}
              onChange={handleChange}
              disabled={!isEditing}
              placeholder="Ej: Norte, Sur, Centro"
            />
          </div>

          <div style={{ display: 'flex', gap: '12px', marginTop: '24px' }}>
            {!isEditing ? (
              <button 
                type="button"
                className="btn btn-primary" 
                style={{ flex: 1 }}
                onClick={() => setIsEditing(true)}
              >
                Editar Perfil
              </button>
            ) : (
              <>
                <button 
                  type="submit" 
                  className="btn btn-success" 
                  style={{ flex: 1 }}
                  disabled={loading}
                >
                  <Save size={20} />
                  {loading ? 'Guardando...' : 'Guardar Cambios'}
                </button>
                <button 
                  type="button"
                  className="btn btn-secondary" 
                  style={{ flex: 1 }}
                  onClick={() => {
                    setIsEditing(false);
                    setFormData({
                      nombre: user?.nombre || '',
                      email: user?.email || '',
                      telefono: user?.telefono || '',
                      vehiculo: user?.vehiculo || '',
                      zonaAsignada: user?.zonaAsignada || ''
                    });
                  }}
                  disabled={loading}
                >
                  Cancelar
                </button>
              </>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};

export default RepartidorPerfil;