import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LogIn, Mail, Lock, AlertCircle } from 'lucide-react';
import './Auth.css';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const result = await login(email, password);
    
    if (result.success) {
      const user = JSON.parse(localStorage.getItem('orderup_user'));
      const routes = {
        'cliente': '/cliente',
        'empleado': '/empleado',
        'repartidor': '/repartidor',
        'admin': '/admin'
      };
      navigate(routes[user.rol] || '/');
    } else {
      setError(result.error);
    }
    
    setLoading(false);
  };

  // Se eliminó la función quickLogin ya que no se usará

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="auth-header">
          <h1 className="auth-title">
            <span className="logo-text">Order</span>
            <span className="logo-accent">Up</span>
          </h1>
          <p className="auth-subtitle">Inicia sesión en tu cuenta</p>
        </div>

        {error && (
          <div className="alert alert-error">
            <AlertCircle size={20} />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            <label className="form-label">
              <Mail size={16} />
              <span>Correo Electrónico</span>
            </label>
            <input
              type="email"
              className="form-input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="tu@email.com"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">
              <Lock size={16} />
              <span>Contraseña</span>
            </label>
            <input
              type="password"
              className="form-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required 
            />
          </div>

          <button 
            type="submit" 
            className="btn btn-primary btn-lg" 
            disabled={loading}
            style={{ width: '100%' }}
          >
            {loading ? (
              <><div className="spinner" style={{ width: '20px', height: '20px', borderWidth: '2px' }}></div> Iniciando sesión...</>
            ) : (
              <><LogIn size={20} /> Iniciar Sesión</>
            )}
          </button>
        </form>

        {/* Se eliminaron el auth-divider y el quick-login-grid */}

        <div className="auth-footer">
          <p>
            ¿No tienes una cuenta?{' '}
            <Link to="/register" className="auth-link">
              Regístrate aquí
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;