import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { ShoppingCart, User, LogOut, Menu, X, Home, Package } from 'lucide-react';
import './Navbar.css';

const Navbar = () => {
  const { user, logout } = useAuth();
  const { getCartCount } = useCart();
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  // Ocultar navbar en páginas públicas
  const publicRoutes = ['/login', '/register', '/'];
  if (publicRoutes.includes(location.pathname)) {
    return null;
  }

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  const getRoleRoute = () => {
    if (!user) return '/';
    switch (user.rol) {
      case 'cliente':
        return '/cliente';
      case 'empleado':
        return '/empleado';
      case 'repartidor':
        return '/repartidor';
      case 'admin':
        return '/admin';
      default:
        return '/';
    }
  };

  return (
    <nav className="navbar">
      <div className="navbar-container container">
        <Link to={getRoleRoute()} className="navbar-logo">
          <span className="logo-text">Order</span>
          <span className="logo-accent">Up</span>
        </Link>

        <div className="navbar-menu-icon" onClick={toggleMenu}>
          {menuOpen ? <X size={24} /> : <Menu size={24} />}
        </div>

        <div className={`navbar-menu ${menuOpen ? 'active' : ''}`}>
          {user ? (
            <>
              <Link to={getRoleRoute()} className="navbar-item" onClick={() => setMenuOpen(false)}>
                <Home size={20} />
                <span>Inicio</span>
              </Link>

              {user.rol === 'cliente' && (
                <>
                  <Link to="/cliente/pedidos" className="navbar-item" onClick={() => setMenuOpen(false)}>
                    <Package size={20} />
                    <span>Mis Pedidos</span>
                  </Link>
                  <Link to="/cliente/carrito" className="navbar-item navbar-cart" onClick={() => setMenuOpen(false)}>
                    <ShoppingCart size={20} />
                    <span>Carrito</span>
                    {getCartCount() > 0 && (
                      <span className="cart-badge">{getCartCount()}</span>
                    )}
                  </Link>
                </>
              )}

              <Link to={`/${user.rol}/perfil`} className="navbar-item" onClick={() => setMenuOpen(false)}>
                <User size={20} />
                <span>{user.nombre}</span>
              </Link>

              <button onClick={() => { handleLogout(); setMenuOpen(false); }} className="navbar-item navbar-logout">
                <LogOut size={20} />
                <span>Cerrar Sesión</span>
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="navbar-item" onClick={() => setMenuOpen(false)}>
                Iniciar Sesión
              </Link>
              <Link to="/register" className="btn btn-primary" onClick={() => setMenuOpen(false)}>
                Registrarse
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;