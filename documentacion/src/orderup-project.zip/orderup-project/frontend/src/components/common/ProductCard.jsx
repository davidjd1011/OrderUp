import React from 'react';
import { ShoppingCart, Plus } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import './ProductCard.css';

const ProductCard = ({ producto, onViewDetails }) => {
  const { addToCart } = useCart();

  const handleAddToCart = (e) => {
    e.stopPropagation();
    addToCart(producto);
    // Mostrar feedback visual
    e.target.textContent = '¡Agregado!';
    setTimeout(() => {
      if (e.target) {
        e.target.innerHTML = '<svg>...</svg><span>Agregar al Carrito</span>';
      }
    }, 1500);
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0
    }).format(price);
  };

  return (
    <div className="product-card" onClick={onViewDetails}>
      <div className="product-image">
        <img 
          src={producto.imagen || `https://via.placeholder.com/300x200?text=${encodeURIComponent(producto.nombre)}`} 
          alt={producto.nombre}
        />
        {!producto.disponible && (
          <div className="product-unavailable">No disponible</div>
        )}
      </div>
      
      <div className="product-info">
        <div className="product-category">{producto.categoria}</div>
        <h3 className="product-name">{producto.nombre}</h3>
        <p className="product-description">{producto.descripcion}</p>
        
        <div className="product-footer">
          <div className="product-price">{formatPrice(producto.precio)}</div>
          {producto.disponible && (
            <button 
              className="btn btn-primary btn-sm product-add-btn"
              onClick={handleAddToCart}
            >
              <ShoppingCart size={16} />
              <span>Agregar</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
