import React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container container">
        <div className="footer-section">
          <h3 className="footer-title">
            <span className="logo-text">Order</span>
            <span className="logo-accent">Up</span>
          </h3>
          <p className="footer-description">
            Sistema de Gestión de Pedidos para Restaurantes
          </p>
          <p className="footer-university">
            Universidad Antonio José Camacho
          </p>
        </div>

        <div className="footer-section">
          <h4 className="footer-subtitle">Contacto</h4>
          <div className="footer-contact">
            <div className="footer-contact-item">
              <Mail size={16} />
              <span>info@orderup.com</span>
            </div>
            <div className="footer-contact-item">
              <Phone size={16} />
              <span>+57 300 123 4567</span>
            </div>
            <div className="footer-contact-item">
              <MapPin size={16} />
              <span>Cali, Colombia</span>
            </div>
          </div>
        </div>

        <div className="footer-section">
          <h4 className="footer-subtitle">Equipo de Desarrollo</h4>
          <ul className="footer-list">
            <li>Frank Josswar Vente Canchimbo</li>
            <li>Juan David Villarreal Cortes</li>
          </ul>
        </div>

        <div className="footer-section">
          <h4 className="footer-subtitle">Proyecto Académico</h4>
          <p className="footer-text">
            Ingeniería de Software I<br />
            Prof. Gustavo Adolfo Saavedra Perdomo<br />
            2025
          </p>
        </div>
      </div>

      <div className="footer-bottom">
        <div className="container">
          <p className="footer-copyright">
            © 2025 OrderUp. Proyecto Académico - Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
