import React, { createContext, useState, useContext, useEffect } from 'react';

const CartContext = createContext(null);

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart debe usarse dentro de un CartProvider');
  }
  return context;
};

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    // Cargar carrito desde localStorage
    const storedCart = localStorage.getItem('orderup_cart');
    if (storedCart) {
      setCartItems(JSON.parse(storedCart));
    }
  }, []);

  useEffect(() => {
    // Guardar carrito en localStorage
    localStorage.setItem('orderup_cart', JSON.stringify(cartItems));
  }, [cartItems]);

  const addToCart = (product, quantity = 1, personalizaciones = '') => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(
        item => item.idProducto === product.idProducto && item.personalizaciones === personalizaciones
      );

      if (existingItem) {
        return prevItems.map(item =>
          item.idProducto === product.idProducto && item.personalizaciones === personalizaciones
            ? { ...item, cantidad: item.cantidad + quantity }
            : item
        );
      }

      return [...prevItems, {
        ...product,
        cantidad: quantity,
        personalizaciones,
        subtotal: product.precio * quantity
      }];
    });
  };

  const removeFromCart = (productId, personalizaciones = '') => {
    setCartItems(prevItems =>
      prevItems.filter(
        item => !(item.idProducto === productId && item.personalizaciones === personalizaciones)
      )
    );
  };

  const updateQuantity = (productId, quantity, personalizaciones = '') => {
    if (quantity <= 0) {
      removeFromCart(productId, personalizaciones);
      return;
    }

    setCartItems(prevItems =>
      prevItems.map(item =>
        item.idProducto === productId && item.personalizaciones === personalizaciones
          ? { ...item, cantidad: quantity, subtotal: item.precio * quantity }
          : item
      )
    );
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const getCartTotal = () => {
    return cartItems.reduce((total, item) => total + item.subtotal, 0);
  };

  const getCartCount = () => {
    return cartItems.reduce((count, item) => count + item.cantidad, 0);
  };

  const value = {
    cartItems,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    getCartTotal,
    getCartCount
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};
