  import React, { createContext, useState, useContext, useEffect } from 'react';
  import { authService } from '../services/authService';

  const AuthContext = createContext(null);

  export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
      throw new Error('useAuth debe usarse dentro de un AuthProvider');
    }
  return context;
  };

  export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

    useEffect(() => {
      // Verificar si hay un usuario guardado en localStorage
      const storedUser = localStorage.getItem('orderup_user');
      if (storedUser) {
        // Asegúrate de que el usuario tiene el 'rol' para la navegación
        setUser(JSON.parse(storedUser));
      }
      // Se establece en false después de la verificación inicial
      setLoading(false);
    }, []);

    // ------------------------------------------------------------------
    // FUNCIÓN CRÍTICA: LOGIN
    // ------------------------------------------------------------------
    const login = async (email, password) => {
      try {
        // Esperamos que authService.login() devuelva el objeto de usuario (con el rol)
        const userData = await authService.login(email, password);
        
        // 🚨 ¡Verificación crucial! Asegúrate de que userData no es nulo/undefined
        if (!userData || !userData.rol) {
            // Esto puede ocurrir si el backend devuelve 200 pero sin datos útiles
            return { success: false, error: 'Respuesta de servidor incompleta o faltante.' };
        }
        
        setUser(userData);
        localStorage.setItem('orderup_user', JSON.stringify(userData));
        
        // Si todo fue bien, retornamos éxito
        return { success: true };
        
      } catch (error) {
        // Captura errores de red, 401, 404, etc. lanzados por authService.login
        return { success: false, error: error.message || 'Error de autenticación desconocido.' };
      }
    };
    // ------------------------------------------------------------------


    const register = async (userData) => {
      try {
        const newUser = await authService.register(userData);
        setUser(newUser);
        localStorage.setItem('orderup_user', JSON.stringify(newUser));
        return { success: true };
      } catch (error) {
        return { success: false, error: error.message };
      }
    };

   const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
    setIsAuthenticated(false);
  };

    const updateUser = (updatedData) => {
      const updatedUser = { ...user, ...updatedData };
      setUser(updatedUser);
      localStorage.setItem('orderup_user', JSON.stringify(updatedUser));
    };

    const value = {
      user,
      loading,
      login,
      register,
      logout,
      updateUser,
      isAuthenticated: !!user,
      isCliente: user?.rol === 'cliente',
      isEmpleado: user?.rol === 'empleado',
      isRepartidor: user?.rol === 'repartidor',
      isAdmin: user?.rol === 'admin'
    };

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
  };