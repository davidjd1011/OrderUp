# 📘 Guía Rápida - OrderUp

## 🎯 Información del Proyecto

**Nombre:** OrderUp - Sistema de Gestión de Pedidos para Restaurantes

**Estudiantes:**
- Frank Josswar Vente Canchimbo (Frontend & Análisis)
- Juan David Villarreal Cortes (Backend & Arquitectura)

**Universidad:** Antonio José Camacho  
**Asignatura:** Ingeniería de Software I  
**Docente:** Gustavo Adolfo Saavedra Perdomo  
**Fecha:** Noviembre 2025

## 🏗️ Arquitectura Implementada

### **Arquitectura por Capas (3 Capas)**

#### 1. Capa de Presentación
- **Tecnología:** React 18.3 + Vite 5.4
- **Ubicación:** `/frontend/src/`
- **Componentes:**
  - `components/common/` - Navbar, Footer, ProductCard, ProtectedRoute
  - `pages/cliente/` - Catálogo, Carrito, Pedidos, Perfil
  - `pages/empleado/` - Gestión de pedidos y almacén
  - `pages/repartidor/` - Entregas asignadas
  - `pages/admin/` - Dashboard administrativo

#### 2. Capa de Lógica de Negocio
- **Ubicación:** `/frontend/src/services/`
- **Servicios:**
  - `authService.js` - Autenticación y autorización
  - `productService.js` - Gestión de productos
  - `pedidoService.js` - Gestión de pedidos (núcleo)
  - `inventarioService.js` - Control de inventario
  - `reporteService.js` - Generación de reportes

#### 3. Capa de Datos
- **Tecnología:** JSON Server (simulado para desarrollo)
- **Ubicación:** `/backend/db.json`
- **Entidades:** Usuarios, Productos, Pedidos, Inventario

## 🎨 Diseño Visual

### Paleta de Colores (Inspirada en Mercado Libre - Azul)
- **Azul Primario:** #3483fa
- **Azul Oscuro:** #2968c8
- **Azul Claro:** #e6f4ff
- **Amarillo Acento:** #ffe600
- **Éxito:** #00a650
- **Advertencia:** #ff9900
- **Error:** #f23d4f

## 👥 Roles y Funcionalidades

### 1. Cliente (cliente@orderup.com / cliente123)
✅ Navegación y búsqueda de productos por categoría  
✅ Agregar productos al carrito con personalizaciones  
✅ Realizar pedidos con dirección y método de pago  
✅ Consultar historial de pedidos  
✅ Seguimiento en tiempo real del estado  
✅ Gestión de perfil personal  

### 2. Empleado de Almacén (empleado@orderup.com / empleado123)
✅ Visualizar pedidos pendientes (Recibido, En Preparación)  
✅ Cambiar estado de pedidos paso a paso  
✅ Asignar repartidores a pedidos listos  
✅ Monitorear inventario con alertas de stock bajo  
✅ Control de preparación de pedidos  

### 3. Repartidor (repartidor@orderup.com / repartidor123)
✅ Ver pedidos asignados  
✅ Información de cliente y dirección de entrega  
✅ Actualizar estado a "Entregado"  
✅ Vista optimizada para móviles  

### 4. Administrador (admin@orderup.com / admin123)
✅ Dashboard con estadísticas generales  
✅ Ventas totales y promedio  
✅ Estado de todos los pedidos  
✅ Top 5 productos más vendidos  
✅ Métricas de clientes y productos  

## 📋 Casos de Uso Implementados

### CU-01: Realizar Pedido ✅
**Actor:** Cliente  
**Flujo:** Catálogo → Carrito → Checkout → Confirmación

### CU-02: Procesar Pedido ✅
**Actor:** Empleado  
**Flujo:** Recibido → En Preparación → Listo para Enviar

### CU-03: Asignar Entrega ✅
**Actor:** Empleado  
**Flujo:** Seleccionar pedido → Asignar repartidor → En Ruta

### CU-04: Actualizar Estado de Entrega ✅
**Actor:** Repartidor  
**Flujo:** Ver pedidos → Entregar → Marcar como Entregado

### CU-05: Consultar Historial ✅
**Actor:** Cliente  
**Flujo:** Mis Pedidos → Ver detalles y estado

## 🔄 Estados de Pedidos

```
Recibido → En Preparación → Listo para Enviar → En Ruta → Entregado
                     ↓
                 Cancelado
```

## 📦 Estructura del Proyecto

```
orderup-project/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── common/          # Componentes reutilizables
│   │   │   ├── cliente/
│   │   │   ├── empleado/
│   │   │   ├── repartidor/
│   │   │   └── admin/
│   │   ├── pages/
│   │   │   ├── cliente/         # Vistas de cliente
│   │   │   ├── empleado/        # Vistas de empleado
│   │   │   ├── repartidor/      # Vistas de repartidor
│   │   │   └── admin/           # Vistas de admin
│   │   ├── services/            # Lógica de negocio
│   │   ├── context/             # Context API (Auth, Cart)
│   │   ├── styles/              # Estilos globales
│   │   ├── App.jsx              # Rutas principales
│   │   └── main.jsx
│   ├── package.json
│   └── vite.config.js
├── backend/
│   └── db.json                  # Base de datos simulada
├── README.md
├── INSTALL.sh                   # Script de instalación Linux/Mac
├── INSTALL.bat                  # Script de instalación Windows
└── GUIA_RAPIDA.md              # Esta guía

```

## 🚀 Instalación y Ejecución

### Paso 1: Extraer el proyecto
```bash
tar -xzf orderup-project.tar.gz
cd orderup-project
```

### Paso 2: Instalar dependencias
```bash
cd frontend
npm install
```

### Paso 3: Iniciar el proyecto

**Terminal 1 - Backend (API):**
```bash
npm run server
```
*Servidor corriendo en: http://localhost:3001*

**Terminal 2 - Frontend:**
```bash
npm run dev
```
*Aplicación corriendo en: http://localhost:5173*

## 🔑 Credenciales de Prueba

| Rol | Email | Contraseña |
|-----|-------|------------|
| Cliente | cliente@orderup.com | cliente123 |
| Empleado | empleado@orderup.com | empleado123 |
| Repartidor | repartidor@orderup.com | repartidor123 |
| Admin | admin@orderup.com | admin123 |

## 🧪 Escenario de Prueba Completo

### 1. Como Cliente:
1. Login con `cliente@orderup.com`
2. Navegar catálogo y buscar productos
3. Agregar productos al carrito
4. Realizar checkout con dirección
5. Confirmar pedido
6. Ver estado en "Mis Pedidos"

### 2. Como Empleado:
1. Login con `empleado@orderup.com`
2. Ver pedido recibido
3. Cambiar a "En Preparación"
4. Cambiar a "Listo para Enviar"
5. Asignar repartidor disponible

### 3. Como Repartidor:
1. Login con `repartidor@orderup.com`
2. Ver pedido asignado
3. Revisar dirección y datos de cliente
4. Marcar como "Entregado"

### 4. Como Admin:
1. Login con `admin@orderup.com`
2. Ver dashboard con estadísticas
3. Revisar ventas totales
4. Ver productos más vendidos

## 🎨 Características Visuales

### Diseño Responsivo
- ✅ Desktop (1200px+)
- ✅ Tablet (768px - 1199px)
- ✅ Mobile (< 768px)

### Componentes UI
- Cards con hover effects
- Badges de estado con colores semánticos
- Botones con animaciones
- Formularios con validación visual
- Navbar sticky con carrito flotante
- Footer informativo

## 📊 Modelo de Datos

### Usuarios
- Cliente (navegación y pedidos)
- Empleado (gestión de almacén)
- Repartidor (entregas)
- Admin (administración general)

### Productos
- Información completa (nombre, precio, categoría)
- Imágenes de referencia
- Estado de disponibilidad

### Pedidos
- Relación con Cliente, Detalles, Repartidor
- Estados del flujo completo
- Tracking temporal

### Inventario
- Control de ingredientes
- Alertas de stock bajo
- Nivel mínimo configurable

## 🔧 Tecnologías Utilizadas

### Frontend
- **React 18.3** - Librería UI
- **Vite 5.4** - Build tool
- **React Router DOM 6** - Enrutamiento
- **Lucide React** - Iconos
- **Context API** - Manejo de estado

### Backend (Simulado)
- **JSON Server** - API REST simulada
- **Node.js** - Entorno de ejecución

### Estilos
- **CSS Modules** - Estilos encapsulados
- **CSS Variables** - Theming
- **Flexbox & Grid** - Layouts responsivos

## 📝 Requisitos Funcionales Implementados

| ID | Requisito | Estado |
|----|-----------|--------|
| RF-01 | Registrar pedidos | ✅ |
| RF-02 | Confirmación automática | ✅ |
| RF-03 | Actualizar estado en tiempo real | ✅ |
| RF-04 | Historial de pedidos por cliente | ✅ |
| RF-05 | Personalizaciones de ingredientes | ✅ |
| RF-06 | Alertas de inventario bajo | ✅ |
| RF-07 | Reportes de ventas | ✅ |
| RF-08 | Múltiples canales de recepción | ✅ |

## 🎓 Documentación Académica

Este proyecto implementa los conceptos aprendidos en:
- **Arquitectura de Software:** Patrón por capas (3 capas)
- **Diseño Orientado a Objetos:** Entidades y relaciones
- **Casos de Uso:** UML completo
- **Pruebas:** Casos de prueba funcionales
- **Interfaz de Usuario:** Diseño centrado en el usuario

## 💡 Mejoras Futuras Propuestas

1. **Autenticación Real:** JWT y bcrypt para seguridad
2. **Base de Datos:** PostgreSQL o MySQL
3. **Notificaciones Push:** En tiempo real con WebSockets
4. **Pasarela de Pagos:** Integración con Stripe/PayU
5. **GPS Tracking:** Seguimiento en vivo del repartidor
6. **App Móvil:** React Native
7. **Sistema de Calificaciones:** Feedback de clientes

## 📞 Soporte y Contacto

**Desarrolladores:**
- Frank Josswar Vente Canchimbo
- Juan David Villarreal Cortes

**Universidad:** Antonio José Camacho  
**Facultad:** Ingeniería de Sistemas  
**Asignatura:** Ingeniería de Software I  
**Docente:** Gustavo Adolfo Saavedra Perdomo

---

## ✅ Lista de Verificación

- [x] Arquitectura por capas implementada
- [x] Autenticación y autorización por roles
- [x] CRUD completo de productos
- [x] Gestión de pedidos con estados
- [x] Carrito de compras funcional
- [x] Dashboards diferenciados por rol
- [x] Diseño responsive (Mobile-First)
- [x] Paleta de colores azul (Mercado Libre style)
- [x] Casos de uso documentados e implementados
- [x] Documentación completa del proyecto

## 🎉 ¡Proyecto Listo para Presentar!

El sistema OrderUp está completamente funcional y listo para ser evaluado. Todos los requisitos académicos han sido cumplidos con coherencia total a la documentación técnica entregada.

**Versión:** 1.0.0  
**Fecha de Entrega:** Noviembre 2025  
**Estado:** ✅ Completado
