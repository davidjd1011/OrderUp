# OrderUp - Sistema de Gestión de Pedidos para Restaurantes

## 🎓 Proyecto Académico
**Institución:** Universidad Antonio José Camacho  
**Facultad:** Ingeniería de Sistemas  
**Asignatura:** Ingeniería de Software I  
**Docente:** Gustavo Adolfo Saavedra Perdomo

## 👥 Equipo de Desarrollo
- **Frank Josswar Vente Canchimbo** - Desarrollador Frontend y Analista de Requisitos
- **Juan David Villarreal Cortes** - Desarrollador Backend y Arquitecto de Software

## 📋 Descripción
OrderUp es una solución tecnológica diseñada para optimizar el proceso completo de recepción, procesamiento y entrega de pedidos en establecimientos de restauración. El sistema busca eliminar errores de transcripción, automatizar confirmaciones y proporcionar seguimiento en tiempo real del estado de los pedidos.

## 🏗️ Arquitectura
**Cliente-Servidor en Tres Capas con Diseño Modular**

### Capa de Presentación
- Interfaz Web (React + Vite)
- Panel de Administración
- Notificaciones en tiempo real

### Capa de Lógica de Negocio
- Gestor de Usuarios
- Gestor de Pedidos (Componente núcleo)
- Gestor de Inventario
- Gestor de Facturación
- Gestor de Entregas
- Gestor de Reportes

### Capa de Datos
- Base de Datos (JSON Server para desarrollo)
- Almacenamiento local

## 🚀 Tecnologías Utilizadas

### Frontend
- React 18.3
- Vite 5.4
- React Router DOM 6.x
- Lucide React (iconos)
- CSS Modules

### Backend (Simulado)
- JSON Server (para desarrollo)
- API REST

## 📦 Instalación y Configuración

### Requisitos Previos
- Node.js 18.x o superior
- npm o yarn

### Instalación

1. **Clonar/Extraer el proyecto**
```bash
cd orderup-project
```

2. **Instalar dependencias**
```bash
npm install
```

3. **Iniciar el servidor de desarrollo**

En una terminal:
```bash
npm run server
```

En otra terminal:
```bash
npm run dev
```

4. **Acceder a la aplicación**
- Frontend: http://localhost:5173
- API Backend: http://localhost:3001

## 👤 Usuarios de Prueba

### Cliente
- **Email:** cliente@orderup.com
- **Contraseña:** cliente123

### Empleado de Almacén
- **Email:** empleado@orderup.com
- **Contraseña:** empleado123

### Repartidor
- **Email:** repartidor@orderup.com
- **Contraseña:** repartidor123

### Administrador
- **Email:** admin@orderup.com
- **Contraseña:** admin123

## 🎨 Características Principales

### Para Clientes
- ✅ Navegación de catálogo de productos
- ✅ Carrito de compras interactivo
- ✅ Realización de pedidos
- ✅ Seguimiento en tiempo real
- ✅ Historial de pedidos
- ✅ Perfil de usuario

### Para Empleados de Almacén
- ✅ Visualización de pedidos pendientes
- ✅ Procesamiento de pedidos
- ✅ Control de inventario
- ✅ Asignación de entregas

### Para Repartidores
- ✅ Pedidos asignados
- ✅ Actualización de estados de entrega
- ✅ Rutas de entrega

### Para Administradores
- ✅ Dashboard con métricas
- ✅ Gestión de productos
- ✅ Gestión de usuarios
- ✅ Reportes de ventas
- ✅ Control de inventario

## 📱 Estructura del Proyecto

```
orderup-project/
├── frontend/                 # Aplicación React
│   ├── public/              # Archivos estáticos
│   ├── src/
│   │   ├── components/      # Componentes reutilizables
│   │   │   ├── common/     # Componentes comunes
│   │   │   ├── cliente/    # Componentes de cliente
│   │   │   ├── empleado/   # Componentes de empleado
│   │   │   ├── repartidor/ # Componentes de repartidor
│   │   │   └── admin/      # Componentes de admin
│   │   ├── pages/          # Páginas principales
│   │   ├── services/       # Servicios API
│   │   ├── context/        # Context API
│   │   ├── utils/          # Utilidades
│   │   ├── styles/         # Estilos globales
│   │   ├── App.jsx         # Componente principal
│   │   └── main.jsx        # Punto de entrada
│   ├── package.json
│   └── vite.config.js
│
├── backend/                  # Datos simulados
│   └── db.json              # Base de datos JSON
│
├── docs/                     # Documentación del proyecto
│   └── documentacion-tecnica.pdf
│
└── README.md                 # Este archivo
```

## 🔄 Estados de Pedidos

1. **Recibido** - Pedido registrado en el sistema
2. **En Preparación** - Siendo procesado por el almacén
3. **Listo para Enviar** - Empaquetado y esperando repartidor
4. **En Ruta** - Asignado a repartidor y en camino
5. **Entregado** - Completado exitosamente
6. **Cancelado** - Cancelado por el cliente o sistema

## 🎯 Casos de Uso Implementados

- ✅ CU-01: Realizar Pedido
- ✅ CU-02: Procesar Pedido
- ✅ CU-03: Asignar Entrega
- ✅ CU-04: Actualizar Estado de Entrega
- ✅ CU-05: Consultar Historial de Pedidos

## 📊 Modelo de Datos

### Entidades Principales
- Usuario (Cliente, Empleado, Repartidor, Admin)
- Pedido
- DetallePedido
- Producto
- Inventario
- Factura
- Pago

## 🛠️ Scripts Disponibles

- `npm run dev` - Inicia el servidor de desarrollo
- `npm run build` - Construye la aplicación para producción
- `npm run preview` - Vista previa de la build de producción
- `npm run server` - Inicia el servidor JSON
- `npm run lint` - Ejecuta el linter

## 🐛 Resolución de Problemas

### El servidor no inicia
```bash
# Verificar que el puerto 5173 esté disponible
npm run dev -- --port 3000
```

### La API no responde
```bash
# Verificar que JSON Server esté corriendo
npm run server
```

### Error de dependencias
```bash
# Limpiar caché y reinstalar
rm -rf node_modules package-lock.json
npm install
```

## 📝 Licencia
Este es un proyecto académico desarrollado para fines educativos.

## 📧 Contacto
Para más información sobre el proyecto, contactar a los desarrolladores:
- Frank Josswar Vente Canchimbo
- Juan David Villarreal Cortes

## 🙏 Agradecimientos
- Universidad Antonio José Camacho
- Profesor Gustavo Adolfo Saavedra Perdomo
- Facultad de Ingenierías

---
**Versión:** 1.0.0  
**Fecha:** Noviembre 2025  
**Estado:** En Desarrollo

## 🚀 Inicio Rápido

### Opción 1: Script Automático

**Linux/Mac:**
```bash
./INSTALL.sh
```

**Windows:**
```bash
INSTALL.bat
```

### Opción 2: Manual

```bash
cd frontend
npm install

# Terminal 1 - Backend
npm run server

# Terminal 2 - Frontend
npm run dev
```

Abre http://localhost:5173 en tu navegador.

## 📸 Capturas de Pantalla

### Vista de Cliente
- Catálogo de productos con búsqueda y filtros
- Carrito de compras interactivo
- Historial de pedidos con seguimiento

### Vista de Empleado
- Gestión de pedidos pendientes
- Control de inventario
- Asignación de repartidores

### Vista de Repartidor
- Pedidos asignados
- Información de entrega
- Actualización de estados

### Vista de Administrador
- Dashboard con estadísticas
- Productos más vendidos
- Métricas de ventas

---

**Desarrollado por:**  
Frank Josswar Vente Canchimbo & Juan David Villarreal Cortes  
Universidad Antonio José Camacho - 2025
