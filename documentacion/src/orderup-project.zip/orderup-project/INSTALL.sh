#!/bin/bash

echo "========================================="
echo "  OrderUp - Installation Script"
echo "========================================="
echo ""

# Navigate to frontend
cd frontend

echo "Installing dependencies..."
npm install

echo ""
echo "========================================="
echo "  Installation Complete!"
echo "========================================="
echo ""
echo "To run the project:"
echo ""
echo "1. Start the backend (in one terminal):"
echo "   cd frontend"
echo "   npm run server"
echo ""
echo "2. Start the frontend (in another terminal):"
echo "   cd frontend"
echo "   npm run dev"
echo ""
echo "3. Open your browser at: http://localhost:5173"
echo ""
echo "Test Users:"
echo "  - Cliente: cliente@orderup.com / cliente123"
echo "  - Empleado: empleado@orderup.com / empleado123"
echo "  - Repartidor: repartidor@orderup.com / repartidor123"
echo "  - Admin: admin@orderup.com / admin123"
echo ""
echo "========================================="
